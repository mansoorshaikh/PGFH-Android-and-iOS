//
//  NewPostViewController.h
//  PGFH
//
//  Created by mansoor shaikh on 29/01/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Rate View/RateView.h"

@interface NewPostViewController : UIViewController<RateViewDelegate>
@property (weak, nonatomic) IBOutlet RateView *tasteRateView,*priceRateView,*hygiennseRateView,*serviceRateView;
@end
