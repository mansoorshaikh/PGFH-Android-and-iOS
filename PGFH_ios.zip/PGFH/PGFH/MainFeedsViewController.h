//
//  MainFeedsViewController.h
//  PGFH
//
//  Created by mansoor shaikh on 29/01/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Alertview/CustomIOS7AlertView.h"
@interface MainFeedsViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,CustomIOS7AlertViewDelegate>
@property(nonatomic,retain) IBOutlet UITableView *mainFeedsTableView;
@property(nonatomic,retain) NSMutableArray *mainFeedsArray;
@property(nonatomic,retain) CustomIOS7AlertView *alertView;
@end
