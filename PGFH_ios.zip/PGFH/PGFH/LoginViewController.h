//
//  LoginViewController.h
//  PGFH
//
//  Created by mansoor shaikh on 29/01/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Alertview/CustomIOS7AlertView.h"

@interface LoginViewController : UIViewController<CustomIOS7AlertViewDelegate>
@property(nonatomic,retain) IBOutlet UIButton *loginButton,*loginwithFBButton;
@property(nonatomic,retain) CustomIOS7AlertView *alertView;

@end
