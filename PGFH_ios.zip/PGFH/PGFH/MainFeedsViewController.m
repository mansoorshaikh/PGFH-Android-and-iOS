//
//  MainFeedsViewController.m
//  PGFH
//
//  Created by mansoor shaikh on 29/01/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import "MainFeedsViewController.h"
#import "UIColor+Expanded.h"
#import "FeedDetailsViewController.h"
#import "NewPostViewController.h"
#import "NewAdvertisementViewController.h"
@interface MainFeedsViewController ()

@end

@implementation MainFeedsViewController
@synthesize mainFeedsTableView,mainFeedsArray,alertView;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.navigationController.navigationBarHidden=YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)popViewController{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)filterCategories{
    alertView = [[CustomIOS7AlertView alloc] init];
    
    // Add some custom content to the alert view
    [alertView setContainerView:[self createDemoView]];
    
    // Modify the parameters
    
    [alertView setDelegate:self];
    
    // You may use a Block, rather than a delegate.
    [alertView setOnButtonTouchUpInside:^(CustomIOS7AlertView *alertView_, int buttonIndex) {
        NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, [alertView_ tag]);
        [alertView_ close];
    }];
    
    [alertView setUseMotionEffects:true];
    
    [alertView show];
}

-(void)closeAlert:(id)sender{
    [alertView close];
}

- (UIView *)createDemoView
{
    UIView *demoView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 200, 250)];
    [demoView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"howtoregister_alert_bg.png"]]];
    
    UIImageView *selectcategory=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 200, 50)];
    [selectcategory setImage:[UIImage imageNamed:@"navigationbar.png"]];
    [demoView addSubview:selectcategory];
    
    UILabel *selectCategoryLabel=[[UILabel alloc] initWithFrame:CGRectMake(10, 2, 200, 50)];
    selectCategoryLabel.textColor=[UIColor colorWithHexString:@"FFFFFF"];
    selectCategoryLabel.text=@"Select Category";
    [demoView addSubview:selectCategoryLabel];
    
    NSArray *itemArray = [NSArray arrayWithObjects: @"Char Kuey Teow", @"Char Kuey Teow", @"Char Kuey Teow", nil];
    UISegmentedControl *segmentedControl = [[UISegmentedControl alloc] initWithItems:itemArray];
    segmentedControl.frame = CGRectMake(25, 50, 150, 180);
    [segmentedControl addTarget:self action:@selector(closeAlert:) forControlEvents: UIControlEventValueChanged];
    segmentedControl.segmentedControlStyle = UISegmentedControlStylePlain;
    
    segmentedControl.transform = CGAffineTransformMakeRotation(M_PI / 2.0);
    NSArray *arr = [segmentedControl subviews];
    for (int i = 0; i < [arr count]; i++) {
        UIView *v = (UIView*) [arr objectAtIndex:i];
        NSArray *subarr = [v subviews];
        for (int j = 0; j < [subarr count]; j++) {
            if ([[subarr objectAtIndex:j] isKindOfClass:[UILabel class]]) {
                UILabel *l = (UILabel*) [subarr objectAtIndex:j];
                l.font=[UIFont boldSystemFontOfSize:25];
                l.transform = CGAffineTransformMakeRotation(- M_PI / 2.0); //do the reverse of what Ben did
            }
        }
    }
    [segmentedControl setSelectedSegmentIndex:UISegmentedControlNoSegment];

    [demoView addSubview:segmentedControl];
    
    return demoView;
}

-(IBAction)newFeedPost{
    UIAlertView *alertView_ = [[UIAlertView alloc] initWithTitle:@"PGFH"
                                                         message:@"Main Feeds"
                                                        delegate:self
                                               cancelButtonTitle:@"Cancel"
                                               otherButtonTitles:@"New Food Post",@"New Advertisement Post", nil];
    [alertView_ show];
}

-(void)feedDetails{
    FeedDetailsViewController *feedetails=[[FeedDetailsViewController alloc] initWithNibName:@"FeedDetailsViewController" bundle:nil];
    [self.navigationController pushViewController:feedetails animated:YES];
}

- (void) alertView:(UIAlertView *)alertView_ clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if( 1   == buttonIndex ){ //cancel button
        NewPostViewController *newpost=[[NewPostViewController alloc] initWithNibName:@"NewPostViewController" bundle:nil];
        [self.navigationController pushViewController:newpost animated:YES];
    } else if ( 2 == buttonIndex ){
        NewAdvertisementViewController *newadvpost=[[NewAdvertisementViewController alloc] initWithNibName:@"NewAdvertisementViewController" bundle:nil];
        [self.navigationController pushViewController:newadvpost animated:YES];
    }
}

//tableview view delagates

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;    //count of section
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return 10;    //count number of row from counting array hear cataGorry is An Array
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *MyIdentifier = @"MyIdentifier";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:MyIdentifier];
    
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                  reuseIdentifier:MyIdentifier] ;
    cell.backgroundColor=[UIColor clearColor];
    
    UIImageView *feedImageView=[[UIImageView alloc] initWithFrame:CGRectMake(5, 5, 100, 100)];
    feedImageView.image=[UIImage imageNamed:@"mainfeeds_feedicon.png"];
    [cell.contentView addSubview:feedImageView];
    
    UILabel *tasteLabel=[[UILabel alloc] initWithFrame:CGRectMake(110, 5, 100, 20)];
    tasteLabel.textColor=[UIColor colorWithHexString:@"9ac968"];
    tasteLabel.font=[UIFont systemFontOfSize:14];
    tasteLabel.text=@"Taste : ";
    [cell.contentView addSubview:tasteLabel];
    
    UILabel *tasteValueLabel=[[UILabel alloc] initWithFrame:CGRectMake(200, 5, 50, 20)];
    tasteValueLabel.textColor=[UIColor colorWithHexString:@"000000"];
    tasteValueLabel.font=[UIFont systemFontOfSize:14];
    tasteValueLabel.text=@"4/5";
    [cell.contentView addSubview:tasteValueLabel];
    
    
    UILabel *priceLabel=[[UILabel alloc] initWithFrame:CGRectMake(110, 30, 100, 20)];
    priceLabel.textColor=[UIColor colorWithHexString:@"9ac968"];
    priceLabel.font=[UIFont systemFontOfSize:14];
    priceLabel.text=@"Price : ";
    [cell.contentView addSubview:priceLabel];
    
    UILabel *priceValueLabel=[[UILabel alloc] initWithFrame:CGRectMake(200, 30, 50, 20)];
    priceValueLabel.textColor=[UIColor colorWithHexString:@"000000"];
    priceValueLabel.font=[UIFont systemFontOfSize:14];
    priceValueLabel.text=@"4/5";
    [cell.contentView addSubview:priceValueLabel];
    
    UIImageView *hygennseImageview=[[UIImageView alloc] initWithFrame:CGRectMake(110, 50, 46, 22)];
    [hygennseImageview setImage:[UIImage imageNamed:@"hyginnse.png"]];
    [cell.contentView addSubview:hygennseImageview];
    
    UILabel *hygennseValueLabel=[[UILabel alloc] initWithFrame:CGRectMake(200, 50, 50, 20)];
    hygennseValueLabel.textColor=[UIColor colorWithHexString:@"000000"];
    hygennseValueLabel.font=[UIFont systemFontOfSize:14];
    hygennseValueLabel.text=@"4/5";
    [cell.contentView addSubview:hygennseValueLabel];
    
    UILabel *serviceLabel=[[UILabel alloc] initWithFrame:CGRectMake(110, 70, 100, 20)];
    serviceLabel.textColor=[UIColor colorWithHexString:@"9ac968"];
    serviceLabel.font=[UIFont systemFontOfSize:14];
    serviceLabel.text=@"Service : ";
    [cell.contentView addSubview:serviceLabel];
    
    UILabel *serviceValueLabel=[[UILabel alloc] initWithFrame:CGRectMake(200, 70, 50, 20)];
    serviceValueLabel.textColor=[UIColor colorWithHexString:@"000000"];
    serviceValueLabel.font=[UIFont systemFontOfSize:14];
    serviceValueLabel.text=@"4/5";
    [cell.contentView addSubview:serviceValueLabel];
    
    UIButton *moreButton=[[UIButton alloc] initWithFrame:CGRectMake(225, 100, 70, 30)];
    [moreButton setBackgroundImage:[UIImage imageNamed:@"mainfeed_more.png"] forState:UIControlStateNormal];
    [moreButton addTarget:self action:@selector(feedDetails) forControlEvents:UIControlEventTouchUpInside];
    [cell.contentView addSubview:moreButton];
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 150;
}

@end
