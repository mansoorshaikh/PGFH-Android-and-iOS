//
//  NewPostViewController.m
//  PGFH
//
//  Created by mansoor shaikh on 29/01/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import "NewPostViewController.h"

@interface NewPostViewController ()

@end

@implementation NewPostViewController
@synthesize tasteRateView,priceRateView,hygiennseRateView,serviceRateView;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    //taste rate view
    self.tasteRateView.notSelectedImage = [UIImage imageNamed:@"kermit_empty.png"];
    self.tasteRateView.halfSelectedImage = [UIImage imageNamed:@"kermit_half.png"];
    self.tasteRateView.fullSelectedImage = [UIImage imageNamed:@"kermit_full.png"];
    self.tasteRateView.rating = 0;
    self.tasteRateView.editable = YES;
    self.tasteRateView.maxRating = 5;
    self.tasteRateView.delegate = self;

    //Hygiennse rate view
    self.hygiennseRateView.notSelectedImage = [UIImage imageNamed:@"kermit_empty.png"];
    self.hygiennseRateView.halfSelectedImage = [UIImage imageNamed:@"kermit_half.png"];
    self.hygiennseRateView.fullSelectedImage = [UIImage imageNamed:@"kermit_full.png"];
    self.hygiennseRateView.rating = 0;
    self.hygiennseRateView.editable = YES;
    self.hygiennseRateView.maxRating = 5;
    self.hygiennseRateView.delegate = self;
    
    //price rate view
    self.priceRateView.notSelectedImage = [UIImage imageNamed:@"kermit_empty.png"];
    self.priceRateView.halfSelectedImage = [UIImage imageNamed:@"kermit_half.png"];
    self.priceRateView.fullSelectedImage = [UIImage imageNamed:@"kermit_full.png"];
    self.priceRateView.rating = 0;
    self.priceRateView.editable = YES;
    self.priceRateView.maxRating = 5;
    self.priceRateView.delegate = self;
    
    //service rate view
    self.serviceRateView.notSelectedImage = [UIImage imageNamed:@"kermit_empty.png"];
    self.serviceRateView.halfSelectedImage = [UIImage imageNamed:@"kermit_half.png"];
    self.serviceRateView.fullSelectedImage = [UIImage imageNamed:@"kermit_full.png"];
    self.serviceRateView.rating = 0;
    self.serviceRateView.editable = YES;
    self.serviceRateView.maxRating = 5;
    self.serviceRateView.delegate = self;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    [textField resignFirstResponder];
    
    return NO;
    
}

- (void)rateView:(RateView *)rateView ratingDidChange:(float)rating {
    NSLog(@"%f",rating);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)popViewController{
    [self.navigationController popViewControllerAnimated:YES];
}
@end
