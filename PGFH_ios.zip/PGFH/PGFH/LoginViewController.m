//
//  LoginViewController.m
//  PGFH
//
//  Created by mansoor shaikh on 29/01/15.
//  Copyright (c) 2015 MobiWebCode. All rights reserved.
//

#import "LoginViewController.h"
#import "MainFeedsViewController.h"
#import "UIColorExpanded/UIColor+Expanded.h";
@interface LoginViewController ()

@end

@implementation LoginViewController
@synthesize loginButton,loginwithFBButton,alertView;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.navigationController.navigationBarHidden=YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)loginAction{
    MainFeedsViewController *mainFeeds=[[MainFeedsViewController alloc] initWithNibName:@"MainFeedsViewController" bundle:nil];
    [self.navigationController pushViewController:mainFeeds animated:YES];
}

-(IBAction)howToRegister{
    alertView = [[CustomIOS7AlertView alloc] init];
    
    // Add some custom content to the alert view
    [alertView setContainerView:[self createDemoView]];
    
    // Modify the parameters
    
    [alertView setDelegate:self];
    
    // You may use a Block, rather than a delegate.
    [alertView setOnButtonTouchUpInside:^(CustomIOS7AlertView *alertView_, int buttonIndex) {
        NSLog(@"Block: Button at position %d is clicked on alertView %d.", buttonIndex, [alertView_ tag]);
        [alertView_ close];
    }];
    
    [alertView setUseMotionEffects:true];
    
    // And launch the dialog
    [alertView show];
}

-(void)closeAlert:(id)sender{
    [alertView close];
}

- (UIView *)createDemoView
{
    UIView *demoView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 400)];
    [demoView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"howtoregister_alert_bg.png"]]];
    
    UITextView *howtoRegister_text=[[UITextView alloc] initWithFrame:CGRectMake(0, 25, 300, 350)];
    howtoRegister_text.textColor=[UIColor colorWithHexString:@"000000"];
    howtoRegister_text.text=@"1. Please go to Facebook. \n 2. Search for PG Food Hunter A Team. \n 3. Click on \"Join Group\" Button. \n 4. Wait for Approval. \n 5. Once approved you can use this app.";
    howtoRegister_text.font=[UIFont systemFontOfSize:20];
    [demoView addSubview:howtoRegister_text];
    
    UIButton *register_ok_Button=[[UIButton alloc] initWithFrame:CGRectMake(75, 340, 150, 40)];
    [register_ok_Button setTitle:@"OK" forState:UIControlStateNormal];
    [register_ok_Button addTarget:self
                       action:@selector(closeAlert:)
             forControlEvents:UIControlEventTouchUpInside];
    [register_ok_Button setBackgroundImage:[UIImage imageNamed:@"navigationbar.png"] forState:UIControlStateNormal];
    register_ok_Button.tag=1;
    [demoView addSubview:register_ok_Button];

    
    return demoView;
}

@end
