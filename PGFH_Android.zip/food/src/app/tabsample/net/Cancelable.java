package app.tabsample.net;

public interface Cancelable {
	public void cancel();
}