package com.mobiwebcode.pgfh;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.KeyEvent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class NewAdvertisingPostActivity extends Activity {
	Constants constants = null;
	private static final int PICK_FROM_CAMERA = 1;
	private static final int PICK_FROM_FILE = 2;
	private Uri mImageCaptureUri;
	private String mPath = "";
	String img_Decodable_Str;
	ArrayList<Bitmap> selectedImages = new ArrayList<Bitmap>();
	ProgressDialog prgDialog;
	String encodedString;
	TextView content;
	BufferedReader reader = null;
	Bitmap photo = null;
	String path = "";
	String AddressC = "";
	ImageView contactValidationImage, locationValidationImage,
			outletValidationImage, descriptionValidationImage;
	Button btn_submit, btn_addphoto;
	ImageView viewImage;
	EditText searchEditText;
	Button clearable_button_clear;

	EditText Outlet, Location, Latitude, Longitude, Contact, Description;
	ImageView foodpostimage1, foodpostimage2, foodpostimage3, foodpostimage4;

	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
		if (!Location_Map.AddressC.equals("")
				&& !Location_Map.AddressC.equals(AddressC)) {
			Location.setText(Location_Map.AddressC);
		} else {
			Location.setText(AddressC);
		}
	}

	void clearFields() {
		Outlet.setText("");
		Contact.setText("");
		Description.setText("");
		foodpostimage1.setImageBitmap(null);
		foodpostimage2.setImageBitmap(null);
		foodpostimage3.setImageBitmap(null);
		foodpostimage4.setImageBitmap(null);

		selectedImages.clear();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.newadvertisingpost_main);
		constants = new Constants(NewAdvertisingPostActivity.this);

		foodpostimage1 = (ImageView) findViewById(R.id.foodpostimage1);
		foodpostimage2 = (ImageView) findViewById(R.id.foodpostimage2);
		foodpostimage3 = (ImageView) findViewById(R.id.foodpostimage3);
		foodpostimage4 = (ImageView) findViewById(R.id.foodpostimage4);

		searchEditText = (EditText) findViewById(R.id.search);
		searchEditText
				.setOnEditorActionListener(new TextView.OnEditorActionListener() {
					@Override
					public boolean onEditorAction(TextView v, int actionId,
							KeyEvent event) {
						if (actionId == EditorInfo.IME_ACTION_SEARCH) {
							if (!searchEditText.getText().toString().equals("")) {
								MainFeedListActivity.searchKeyword = searchEditText
										.getText().toString();
								Intent intent = new Intent(
										NewAdvertisingPostActivity.this,
										MainFeedListActivity.class);
								startActivity(intent);
							}
							return true;
						}
						return false;
					}
				});

		clearable_button_clear = (Button) findViewById(R.id.clearable_button_clear);
		clearable_button_clear.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				searchEditText.setText("");
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(searchEditText.getWindowToken(), 0);
			}
		});

		Button categoryBtn = (Button) findViewById(R.id.btn_categories);

		categoryBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				constants.showCategoryDialogue();
			}
		});
		Button postBtn = (Button) findViewById(R.id.btn_post);
		postBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				constants.showPostDialogue();
			}
		});

		contactValidationImage = (ImageView) findViewById(R.id.contactValidationImage);
		locationValidationImage = (ImageView) findViewById(R.id.locationValidationImage);
		outletValidationImage = (ImageView) findViewById(R.id.outletValidationImage);
		descriptionValidationImage = (ImageView) findViewById(R.id.descriptionValidationImage);

		Outlet = (EditText) findViewById(R.id.Outlet);
		Location = (EditText) findViewById(R.id.Location);
		Latitude = (EditText) findViewById(R.id.Latitude);
		Longitude = (EditText) findViewById(R.id.Longitude);

		Contact = (EditText) findViewById(R.id.contact);
		Description = (EditText) findViewById(R.id.description);

		Location.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				startActivity(new Intent(NewAdvertisingPostActivity.this,
						Location_Map.class));
			}
		});

		Longitude.setText("" + MainFeedListActivity.Longutude);
		Latitude.setText("" + MainFeedListActivity.Latitude);

		btn_addphoto = (Button) findViewById(R.id.btn_addphoto);
		btn_addphoto.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				// TODO Auto-generated method stub
				showPictureDialogue();
			}
		});

		btn_submit = (Button) findViewById(R.id.btn_submit);
		btn_submit.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				boolean outlet = constants.validateText(Outlet,
						outletValidationImage);
				boolean location = constants.validateText(Location,
						locationValidationImage);
				boolean contact_ = constants.validateText(Contact,
						contactValidationImage);
				boolean description_ = constants.validateText(Description,
						descriptionValidationImage);

				if (outlet && location && contact_ && description_) {
					try {
						uploadData();
					} catch (Exception e) {
						// TODO: handle exception
					}
				}
			}
		});

		NewAdvertisingPostActivity.this.getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

		Geocoder gCoder = new Geocoder(NewAdvertisingPostActivity.this);
		ArrayList<Address> addresses = null;
		if (MainFeedListActivity.Latitude != null
				&& MainFeedListActivity.Longutude != null) {
			try {
				addresses = (ArrayList<Address>) gCoder.getFromLocation(
						MainFeedListActivity.Latitude,
						MainFeedListActivity.Longutude, 2);
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (addresses != null && addresses.size() > 0) {
				if (addresses.get(0).getFeatureName() != null)
					AddressC = addresses.get(0).getFeatureName();
				if (addresses.get(0).getLocality() != null)
					AddressC = AddressC + "-" + addresses.get(0).getLocality();
				if (addresses.get(0).getAdminArea() != null)
					AddressC = AddressC + "-" + addresses.get(0).getAdminArea();
				if (addresses.get(0).getCountryName() != null)
					AddressC = AddressC + "-"
							+ addresses.get(0).getCountryName();
			}
			if (!Location_Map.AddressC.equals("")
					&& !Location_Map.AddressC.equals(AddressC)) {
				Location.setText(Location_Map.AddressC);
			} else {
				Location.setText(AddressC);
			}
		}
	}

	/*
	 * protected void onActivityResult(int requestCode, int resultCode, Intent
	 * data) { super.onActivityResult(requestCode, resultCode, data); if
	 * (resultCode != RESULT_OK) return;
	 * 
	 * switch (requestCode) {
	 * 
	 * case PICK_FROM_FILE:
	 * 
	 * 
	 * if (requestCode == PICK_FROM_FILE && resultCode == RESULT_OK && null !=
	 * data) { Uri selectedImage = data.getData(); String[] filePathColumn = {
	 * MediaStore.Images.Media.DATA }; Cursor cursor =
	 * getContentResolver().query(selectedImage,filePathColumn, null, null,
	 * null); cursor.moveToFirst(); int columnIndex =
	 * cursor.getColumnIndex(filePathColumn[0]); String picturePath =
	 * cursor.getString(columnIndex); cursor.close();
	 * 
	 * Bitmap bitmap = BitmapFactory.decodeFile(picturePath);
	 * if(bitmap.getHeight()>=2048||bitmap.getWidth()>=2048){ DisplayMetrics
	 * metrics = new DisplayMetrics();
	 * getWindowManager().getDefaultDisplay().getMetrics(metrics); int width =
	 * metrics.widthPixels; int height = metrics.heightPixels; bitmap
	 * =Bitmap.createScaledBitmap(bitmap, width, height, true); } ImageView
	 * viewImage = (ImageView) findViewById(R.id.setimageview);
	 * viewImage.setImageBitmap(getScaledBitmap(picturePath, 800, 800));
	 * viewImage.setImageBitmap(BitmapFactory.decodeFile(picturePath));
	 * 
	 * 
	 * }
	 * 
	 * break;
	 * 
	 * case PICK_FROM_CAMERA: if (requestCode == PICK_FROM_CAMERA && resultCode
	 * == RESULT_OK) { Bitmap photo = (Bitmap) data.getExtras().get("data");
	 * viewImage.setImageBitmap(photo); } break;
	 * 
	 * 
	 * } }
	 */

	public void showPictureDialogue() {
		final Dialog dialog = new Dialog(NewAdvertisingPostActivity.this);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.choseoptionforpicture);

		Button btnGallary = (Button) dialog.findViewById(R.id.btnGallary);
		// if button is clicked, close the custom dialog
		btnGallary.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setType("image/*");
				intent.setAction(Intent.ACTION_GET_CONTENT);
				startActivityForResult(
						Intent.createChooser(intent, "Select Picture"),
						PICK_FROM_FILE);
				dialog.dismiss();
			}
		});

		Button btnCamera = (Button) dialog.findViewById(R.id.btnCamera);
		// if button is clicked, close the custom dialog
		btnCamera.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				try {

					Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
					File file = new File(Environment
							.getExternalStorageDirectory(), "aaa_"
							+ String.valueOf(System.currentTimeMillis())
							+ ".jpg");
					mImageCaptureUri = Uri.fromFile(file);

					intent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
							mImageCaptureUri);
					intent.putExtra("return-data", true);

					startActivityForResult(intent, PICK_FROM_CAMERA);
					dialog.dismiss();
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
		});
		ImageView dialogButton = (ImageView) dialog.findViewById(R.id.closebtn);
		dialogButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});

		dialog.show();
	}

	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode != RESULT_OK)
			return;
		else {
			Bitmap photo = null;

			if (requestCode == PICK_FROM_CAMERA && resultCode == RESULT_OK) {
				mPath = mImageCaptureUri.getPath();
				photo = BitmapFactory.decodeFile(mPath);
			} else {
				Uri selectedImage = data.getData();
				String[] filePathColumn = { MediaStore.Images.Media.DATA };
				Cursor cursor = getContentResolver().query(selectedImage,
						filePathColumn, null, null, null);
				cursor.moveToFirst();
				int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
				String picturePath = cursor.getString(columnIndex);
				cursor.close();

				photo = BitmapFactory.decodeFile(picturePath);

			}

			photo = Bitmap.createScaledBitmap(photo, 60, 60, true);
			if (selectedImages.size() == 0) {
				foodpostimage1.setImageBitmap(photo);
			} else if (selectedImages.size() == 1) {
				foodpostimage2.setImageBitmap(photo);
			} else if (selectedImages.size() == 2) {
				foodpostimage3.setImageBitmap(photo);
			} else if (selectedImages.size() == 3) {
				foodpostimage4.setImageBitmap(photo);
			}
			if (selectedImages.size() <= 3) {
				selectedImages.add(photo);
			} else {
				final Dialog dialog_alert = new Dialog(
						NewAdvertisingPostActivity.this);
				dialog_alert.requestWindowFeature(Window.FEATURE_NO_TITLE);
				dialog_alert.setContentView(R.layout.common_alert);

				TextView dialogueTextView = (TextView) dialog_alert
						.findViewById(R.id.text);
				dialogueTextView
						.setText("You can't add more than 4 images!!!.");

				Button closebtn = (Button) dialog_alert
						.findViewById(R.id.dialogButtonOK);
				closebtn.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated
						// method stub
						dialog_alert.dismiss();
					}
				});
				dialog_alert.show();

			}
		}
	}

	private Bitmap combineImageIntoOne(ArrayList<Bitmap> bitmap) {
		int w = 0, h = 0;
		Bitmap temp = null;
		if (bitmap.size() == 2) {
			temp = Bitmap.createBitmap(120, 60, Bitmap.Config.ARGB_8888);
		} else {
			temp = Bitmap.createBitmap(120, 120, Bitmap.Config.ARGB_8888);
		}
		Canvas canvas = new Canvas(temp);
		int top = 0;
		for (int i = 0; i < bitmap.size(); i++) {
			Bitmap currentBitmap = bitmap.get(i);
			if (i == 0)
				canvas.drawBitmap(bitmap.get(i), 0f, 0f, null);
			else if (i == 1)
				canvas.drawBitmap(bitmap.get(i), 60f, 0f, null);
			else if (bitmap.size() == 3) {
				if (i == 2)
					canvas.drawBitmap(Bitmap.createScaledBitmap(bitmap.get(i),
							120, 60, true), 0f, 60f, null);
			} else if (i == 2)
				canvas.drawBitmap(bitmap.get(i), 0f, 60f, null);
			else if (i == 3)
				canvas.drawBitmap(bitmap.get(i), 60f, 60f, null);
		}
		return temp;
	}

	// Create GetText Metod
	public void uploadData() throws UnsupportedEncodingException {

		final Thread worker = new Thread(new Runnable() {
			public void run() {/* work thread stuff here */
				ArrayList<NameValuePair> nameValuePair = new ArrayList<NameValuePair>();
				ByteArrayOutputStream baos = new ByteArrayOutputStream();
				Bitmap bi = null;
				if (selectedImages.size() == 1) {
					bi = (Bitmap) selectedImages.get(0);
				} else {
					bi = combineImageIntoOne(selectedImages);
				}
				bi.compress(Bitmap.CompressFormat.PNG, 100, baos);
				byte[] data = baos.toByteArray();
				nameValuePair.add(new BasicNameValuePair("image", Base64
						.encodeToString(data, 0)));

				nameValuePair.add(new BasicNameValuePair("outlet", Outlet
						.getText().toString()));
				nameValuePair.add(new BasicNameValuePair("location", Location
						.getText().toString()));
				nameValuePair.add(new BasicNameValuePair("latitude", Latitude
						.getText().toString()));
				nameValuePair.add(new BasicNameValuePair("longitude", Longitude
						.getText().toString()));
				nameValuePair.add(new BasicNameValuePair("description",
						Description.getText().toString()));
				nameValuePair.add(new BasicNameValuePair("contact", Contact
						.getText().toString()));
				try {

					// Defined URL where to send data
					HttpClient httpclient = new DefaultHttpClient();
					HttpPost httppost = new HttpPost(
							"http://www.mobiwebcode.com/pgfh/admin/mobile_newadvtpost_android.php");
					httppost.setHeader("Content-Type",
							"application/x-www-form-urlencoded;");
					httppost.setEntity(new UrlEncodedFormEntity(nameValuePair,
							"UTF-8"));
					HttpResponse response = httpclient.execute(httppost);
					String responseText = EntityUtils.toString(response
							.getEntity());
					System.out.println(responseText);

				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		worker.start();
		// observer thread for notifications
		final Thread joiner = new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {
					worker.join();
				} catch (Exception e) {
					// TODO: handle exception
				} finally {
					NewAdvertisingPostActivity.this
							.runOnUiThread(new Runnable() {

								@Override
								public void run() {
									// TODO Auto-generated method stub
									final Dialog dialog_alert = new Dialog(
											NewAdvertisingPostActivity.this);
									dialog_alert
											.requestWindowFeature(Window.FEATURE_NO_TITLE);
									dialog_alert
											.setContentView(R.layout.common_alert);

									TextView dialogueTextView = (TextView) dialog_alert
											.findViewById(R.id.text);
									dialogueTextView
											.setText("Advt Post Posted Successfully.");

									Button closebtn = (Button) dialog_alert
											.findViewById(R.id.dialogButtonOK);
									closebtn.setOnClickListener(new OnClickListener() {

										@Override
										public void onClick(View v) {
											// TODO Auto-generated
											// method stub
											dialog_alert.dismiss();
											clearFields();
										}
									});
									dialog_alert.show();

								}
							});
				}
			}
		});
		joiner.start();

	}

	public void onBackPressed() {
		Intent intent = new Intent(this, MainFeedListActivity.class);
		startActivity(intent);
	}
}
