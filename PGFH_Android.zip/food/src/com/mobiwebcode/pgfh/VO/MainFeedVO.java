package com.mobiwebcode.pgfh.VO;

import java.util.ArrayList;

public class MainFeedVO {
	public String userid = "", username = "", userimage = "", message = "",
			feeddatetime = "", story = "", description = "", sharedLink = "",
			feedid = "";
	public ArrayList<String> feedImagesList = new ArrayList<String>();
	public ArrayList<CommentVO> commentList = new ArrayList<CommentVO>();
}
