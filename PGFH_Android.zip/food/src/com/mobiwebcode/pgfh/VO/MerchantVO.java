package com.mobiwebcode.pgfh.VO;

public class MerchantVO {
	public String merchantid = "", merchantname = "", merchantdescription = "";
}
