package com.mobiwebcode.pgfh.VO;

import java.util.ArrayList;

public class CommentVO {
	public String commentid = "", commentuserid = "", commentusername = "",
			commentuserimage = "", commentdatetime = "", commentmessage = "",
			commentPagingURL = "";
	public ArrayList<String> commentImages = new ArrayList<String>();
}
