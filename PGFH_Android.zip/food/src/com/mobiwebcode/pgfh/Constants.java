package com.mobiwebcode.pgfh;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;

public class Constants {

	Activity mContext = null;

	public Constants(Activity context) {
		// TODO Auto-generated constructor stub
		mContext = context;
	}

	boolean validateText(EditText editText, ImageView validateImageView) {
		if (editText.getText().toString().equals("")) {
			validateImageView.setVisibility(View.VISIBLE);
			return false;
		} else {
			validateImageView.setVisibility(View.GONE);
			return true;
		}
	}

	boolean validateText(RatingBar ratingBar, ImageView validateImageView) {
		if (ratingBar.getRating() == 0.00f) {
			validateImageView.setVisibility(View.VISIBLE);
			return false;
		} else {
			validateImageView.setVisibility(View.GONE);
			return true;
		}
	}

	public boolean isOnline() {
		ConnectivityManager cm = (ConnectivityManager) mContext
				.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();
		return netInfo != null && netInfo.isConnectedOrConnecting();
	}

	public void showCategoryDialogue() {
		final Dialog dialog = new Dialog(mContext);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.categorydialog);

		LinearLayout categoryLinearLayout = (LinearLayout) dialog
				.findViewById(R.id.categoryLinearLayout);
		for (int count = 0; count < MainFeedListActivity.categoryList.length; count++) {
			Button categoryButton = new Button(dialog.getContext());
			categoryButton.setBackgroundColor(Color.BLACK);
			categoryButton.setTextColor(Color.WHITE);
			categoryButton.setText(MainFeedListActivity.categoryList[count]);

			LayoutParams categoryButton_LayoutParams = new LayoutParams(
					LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
			categoryButton_LayoutParams.setMargins(0, 5, 0, 5);
			categoryButton.setLayoutParams(categoryButton_LayoutParams);
			categoryLinearLayout.addView(categoryButton);
		}

		ImageView dialogButton = (ImageView) dialog.findViewById(R.id.closebtn);

		dialogButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});

		dialog.show();
	}

	public void showPostDialogue() {
		final Dialog dialog = new Dialog(mContext);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.choseoption);

		Button buttonAdevertise = (Button) dialog
				.findViewById(R.id.btnAdvertise);
		// if button is clicked, close the custom dialog
		buttonAdevertise.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(mContext,
						NewAdvertisingPostActivity.class);
				mContext.startActivity(intent);
				dialog.dismiss();

			}
		});

		Button buttonFoodpost = (Button) dialog.findViewById(R.id.btnfood);
		// if button is clicked, close the custom dialog
		buttonFoodpost.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(mContext, NewFoodPostActivity.class);
				mContext.startActivity(intent);
				dialog.dismiss();

			}
		});
		ImageView dialogButton = (ImageView) dialog.findViewById(R.id.closebtn);
		dialogButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});

		dialog.show();
	}

	public void showRegisterDialogue() {
		final Dialog dialog = new Dialog(mContext);
		dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dialog.setContentView(R.layout.custom);

		TextView text = (TextView) dialog.findViewById(R.id.text);
		text.setText("1)Please go to Facebook. \n"
				+ "2)Search for \"PG Food Hunter a Team\".\n"
				+ "3)Click on Join Group Button.\n" + "4)Wait For Aproval.\n"
				+ "5)Once Approved,You can used this app.");

		ImageView dialogButton = (ImageView) dialog.findViewById(R.id.closebtn);
		dialogButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});

		dialog.show();
	}

}
