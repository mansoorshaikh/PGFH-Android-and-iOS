package com.mobiwebcode.pgfh;

import java.util.Arrays;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.facebook.AppEventsLogger;
import com.facebook.FacebookAuthorizationException;
import com.facebook.FacebookOperationCanceledException;
import com.facebook.HttpMethod;
import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionLoginBehavior;
import com.facebook.SessionState;
import com.facebook.UiLifecycleHelper;
import com.facebook.model.GraphObject;
import com.facebook.model.GraphUser;
import com.facebook.widget.FacebookDialog;
import com.facebook.widget.LoginButton;

public class LoginActivity extends Activity {
	final Context context = this;
	private Button howtoRegisterButton;
	private LoginButton loginButton;
	private GraphUser user;
	private PendingAction pendingAction = PendingAction.NONE;
	private final String PENDING_ACTION_BUNDLE_KEY = "com.mobiwebcode.pgfh:PendingAction";
	String nextFeedsURL = "/146877278771592/feed";
	int count = 0;

	private enum PendingAction {
		NONE, POST_PHOTO, POST_STATUS_UPDATE
	}

	private UiLifecycleHelper uiHelper;

	private Session.StatusCallback callback = new Session.StatusCallback() {
		@Override
		public void call(Session session, SessionState state,
				Exception exception) {
			onSessionStateChange(session, state, exception);
		}
	};

	private void onSessionStateChange(Session session, SessionState state,
			Exception exception) {
		if (pendingAction != PendingAction.NONE
				&& (exception instanceof FacebookOperationCanceledException || exception instanceof FacebookAuthorizationException)) {
			new AlertDialog.Builder(LoginActivity.this)
					.setTitle(R.string.cancelled)
					.setMessage(R.string.permission_not_granted)
					.setPositiveButton(R.string.ok, null).show();
			pendingAction = PendingAction.NONE;
		} else if (state == SessionState.OPENED_TOKEN_UPDATED) {
		}
	}

	private interface GraphObjectWithId extends GraphObject {
		String getId();
	}

	private FacebookDialog.Callback dialogCallback = new FacebookDialog.Callback() {
		@Override
		public void onError(FacebookDialog.PendingCall pendingCall,
				Exception error, Bundle data) {
			Log.d("HelloFacebook", String.format("Error: %s", error.toString()));
		}

		@Override
		public void onComplete(FacebookDialog.PendingCall pendingCall,
				Bundle data) {
			Log.d("HelloFacebook", "Success!");
		}
	};

	@Override
	protected void onSaveInstanceState(Bundle outState) {
		super.onSaveInstanceState(outState);
		uiHelper.onSaveInstanceState(outState);

		outState.putString(PENDING_ACTION_BUNDLE_KEY, pendingAction.name());
	}

	void getGroupFeeds() {
		new Request(Session.getActiveSession(), nextFeedsURL, null,
				HttpMethod.GET, new Request.Callback() {
					public void onCompleted(Response response) {
						if (response.getGraphObject() != null) {
							count++;
							if (count < 5) {
								try {
									GraphObject graphObject = response
											.getGraphObject();
									JSONObject jso = graphObject
											.getInnerJSONObject();
									JSONArray facebookfeedsArray = jso
											.getJSONArray("data");
									System.out.println(facebookfeedsArray);
									JSONObject pagingObject = jso
											.getJSONObject("paging");
									nextFeedsURL = pagingObject.getString(
											"next").split("146877278771592")[1];
									nextFeedsURL = "/146877278771592"
											+ nextFeedsURL;
									getGroupFeeds();
								} catch (Exception e) {
									// TODO: handle exception
								}
							}
						}
					}
				}).executeAsync();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		uiHelper.onActivityResult(requestCode, resultCode, data, dialogCallback);
		System.out.println("Permissions : "
				+ Session.getActiveSession().getPermissions());
		getGroupFeeds();
		/*
		 * new Request(Session.getActiveSession(), "me", null, HttpMethod.GET,
		 * new Request.Callback() { public void onCompleted(Response response) {
		 * if (response.getGraphObject() != null) { final Intent intent = new
		 * Intent( LoginActivity.this, MainFeedListActivity.class);
		 * MainFeedListActivity.userGraphObject = response; GraphObject
		 * graphObject = response.getGraphObject(); JSONObject jso =
		 * graphObject.getInnerJSONObject(); try { new
		 * Request(Session.getActiveSession(), jso .getString("id") + "/groups",
		 * null, HttpMethod.GET, new Request.Callback() { public void
		 * onCompleted( Response response) { GraphObject graphObject = response
		 * .getGraphObject(); JSONObject jso = graphObject
		 * .getInnerJSONObject(); int groupfound = 0; try { JSONArray
		 * facebookGroupsArray = jso .getJSONArray("data");
		 * 
		 * for (int i = 0; i < facebookGroupsArray .length(); i++) { JSONObject
		 * jsonObject = facebookGroupsArray .getJSONObject(i); if (jsonObject
		 * .getString("id") .equals("146877278771592")) { groupfound = 1;
		 * startActivity(intent); } } if (groupfound == 0) { final Dialog dialog
		 * = new Dialog( context);
		 * dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		 * dialog.setContentView(R.layout.nointernetconnection);
		 * 
		 * TextView dialogueTextView = (TextView) dialog
		 * .findViewById(R.id.internetmsgTextView); dialogueTextView .setText(
		 * "Sorry, you are not approved to view this group�s feed. Please take a look at HOW TO REGISTER."
		 * );
		 * 
		 * Button dialogButton = (Button) dialog
		 * .findViewById(R.id.dialogButtonOK);
		 * 
		 * dialogButton .setOnClickListener(new OnClickListener() {
		 * 
		 * @Override public void onClick( View v) { SharedPreferences.Editor
		 * editor = getSharedPreferences( "myPref", MODE_PRIVATE) .edit();
		 * editor.putString( "login", "no"); editor.commit();
		 * Session.getActiveSession() .close(); Session.getActiveSession()
		 * .closeAndClearTokenInformation(); dialog.dismiss(); Intent intent =
		 * getIntent(); finish(); startActivity(intent); } });
		 * 
		 * dialog.show(); }
		 * 
		 * } catch (JSONException e) { // TODO // Auto-generated // catch block
		 * e.printStackTrace(); }
		 * 
		 * } }).executeAsync(); } catch (Exception e) { // TODO: handle
		 * exception e.printStackTrace(); } } else {
		 * 
		 * final Dialog dialog = new Dialog(context);
		 * dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
		 * dialog.setContentView(R.layout.nointernetconnection);
		 * 
		 * Button dialogButton = (Button) dialog
		 * .findViewById(R.id.dialogButtonOK);
		 * 
		 * dialogButton .setOnClickListener(new OnClickListener() {
		 * 
		 * @Override public void onClick(View v) { dialog.dismiss(); } });
		 * 
		 * dialog.show();
		 * 
		 * } } }).executeAsync();
		 */

	}

	@Override
	public void onPause() {
		super.onPause();
		uiHelper.onPause();

		// Call the 'deactivateApp' method to log an app event for use in
		// analytics and advertising
		// reporting. Do so in the onPause methods of the primary Activities
		// that an app may be launched into.
		AppEventsLogger.deactivateApp(this);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		uiHelper.onDestroy();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login_main);

		if (Session.getActiveSession() != null) {
			SharedPreferences prefs = getSharedPreferences("myPref",
					MODE_PRIVATE);

			String login = prefs.getString("login", null);

			if (login.equals("yes")) {
				System.out.println("Permissions : "
						+ Session.getActiveSession().getPermissions());

				Constants constants = new Constants(LoginActivity.this);
				try {
					if (constants.isOnline()) {
						new Request(Session.getActiveSession(), "me", null,
								HttpMethod.GET, new Request.Callback() {
									public void onCompleted(Response response) {
										final Intent intent = new Intent(
												LoginActivity.this,
												MainFeedListActivity.class);
										MainFeedListActivity.userGraphObject = response;
										GraphObject graphObject = response
												.getGraphObject();
										JSONObject jso = graphObject
												.getInnerJSONObject();
										System.out.println();
										try {
											new Request(Session
													.getActiveSession(), jso
													.getString("id")
													+ "/groups", null,
													HttpMethod.GET,
													new Request.Callback() {
														public void onCompleted(
																Response response) {
															GraphObject graphObject = response
																	.getGraphObject();
															JSONObject jso = graphObject
																	.getInnerJSONObject();
															int groupfound = 0;
															try {
																JSONArray facebookGroupsArray = jso
																		.getJSONArray("data");

																for (int i = 0; i < facebookGroupsArray
																		.length(); i++) {
																	JSONObject jsonObject = facebookGroupsArray
																			.getJSONObject(i);
																	if (jsonObject
																			.getString(
																					"id")
																			.equals("146877278771592")) {
																		groupfound = 1;
																		startActivity(intent);
																	}
																}
																if (groupfound == 0) {
																	final Dialog dialog = new Dialog(
																			context);
																	dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
																	dialog.setContentView(R.layout.nointernetconnection);

																	TextView dialogueTextView = (TextView) dialog
																			.findViewById(R.id.internetmsgTextView);
																	dialogueTextView
																			.setText("Sorry, you are not approved to view this group�s feed. Please take a look at HOW TO REGISTER.");

																	Button dialogButton = (Button) dialog
																			.findViewById(R.id.dialogButtonOK);

																	dialogButton
																			.setOnClickListener(new OnClickListener() {
																				@Override
																				public void onClick(
																						View v) {
																					SharedPreferences.Editor editor = getSharedPreferences(
																							"myPref",
																							MODE_PRIVATE)
																							.edit();
																					editor.putString(
																							"login",
																							"no");
																					editor.commit();
																					Session.getActiveSession()
																							.close();
																					Session.getActiveSession()
																							.closeAndClearTokenInformation();
																					dialog.dismiss();
																					Intent intent = getIntent();
																					finish();
																					startActivity(intent);
																				}
																			});
																	dialog.show();
																}
															} catch (JSONException e) {
																e.printStackTrace();
															}
														}
													}).executeAsync();
										} catch (Exception e) {
											// TODO: handle exception
										}
									}
								}).executeAsync();
					} else {
						final Dialog dialog = new Dialog(context);
						dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
						dialog.setContentView(R.layout.nointernetconnection);
						Button dialogButton = (Button) dialog
								.findViewById(R.id.dialogButtonOK);
						dialogButton.setOnClickListener(new OnClickListener() {
							@Override
							public void onClick(View v) {
								dialog.dismiss();
							}
						});

						dialog.show();
					}
				} catch (Exception e) {
					// TODO: handle exception
				}
			}
		}
		uiHelper = new UiLifecycleHelper(this, callback);
		uiHelper.onCreate(savedInstanceState);

		if (savedInstanceState != null) {
			String name = savedInstanceState
					.getString(PENDING_ACTION_BUNDLE_KEY);
			pendingAction = PendingAction.valueOf(name);
		}
		loginButton = (LoginButton) findViewById(R.id.btn_facebooklogin);
		loginButton.setLoginBehavior(SessionLoginBehavior.SUPPRESS_SSO);

		howtoRegisterButton = (Button) findViewById(R.id.btn_howtoregister);
		// add button listener
		howtoRegisterButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				Constants constants = new Constants(LoginActivity.this);
				constants.showRegisterDialogue();
			}
		});

	}

}
