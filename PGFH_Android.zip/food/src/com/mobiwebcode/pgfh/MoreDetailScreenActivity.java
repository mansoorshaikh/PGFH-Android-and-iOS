package com.mobiwebcode.pgfh;

import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.method.ScrollingMovementMethod;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import android.widget.TextView;
import app.tabsample.SmartImageView.SmartImageView;

import com.facebook.HttpMethod;
import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.model.GraphObject;
import com.mobiwebcode.pgfh.MainFeedListActivity.CustomList;
import com.mobiwebcode.pgfh.VO.CommentVO;
import com.mobiwebcode.pgfh.VO.MainFeedVO;

public class MoreDetailScreenActivity extends Activity {
	private Button dilogBtn;
	final Context context = this;
	private Button button;
	public static MainFeedVO selectedMainFeedVO = new MainFeedVO();
	TextView mainMessageTextView;
	LinearLayout feedImagesLayout, feedDetailsLayout, commentsLinearLayout;
	TextView commentsLabelTextView, toplabletext;
	Button postcommentsButton;
	String nextCommentsFeedsURL = "";
	Constants constants = null;
	EditText searchEditText;
	Button clearable_button_clear;

	private JSONArray getFacebookFeedsComments() {
		JSONArray arr = null;
		new Request(Session.getActiveSession(), nextCommentsFeedsURL, null,
				HttpMethod.GET, new Request.Callback() {
					public void onCompleted(Response response) {
						/* handle the result */
						try {
							GraphObject graphObject = response.getGraphObject();
							JSONObject jso = graphObject.getInnerJSONObject();
							JSONArray commentsArray = jso.getJSONArray("data");
							for (int commentcount = 0; commentcount < commentsArray
									.length(); commentcount++) {
								JSONObject commentsObject = (JSONObject) commentsArray
										.get(commentcount);
								CommentVO commentVO = new CommentVO();
								if (!commentsObject.isNull("id"))
									commentVO.commentid = commentsObject
											.getString("id");
								if (!commentsObject.isNull("message"))
									commentVO.commentmessage = commentsObject
											.getString("message");
								if (!commentsObject.isNull("picture"))
									commentVO.commentImages.add(commentsObject
											.getString("picture"));
								if (!commentsObject.isNull("created_time"))
									commentVO.commentdatetime = commentsObject
											.getString("created_time");

								// comment user details
								JSONObject commentuserdetails = commentsObject
										.getJSONObject("from");
								if (!commentuserdetails.isNull("id"))
									commentVO.commentuserid = commentuserdetails
											.getString("id");
								if (!commentuserdetails.isNull("name"))
									commentVO.commentusername = commentuserdetails
											.getString("name");
								JSONObject pagingObject = jso
										.getJSONObject("paging");
								nextCommentsFeedsURL = pagingObject.getString(
										"next").split("v2.2")[1];
								commentVO.commentPagingURL = nextCommentsFeedsURL;
								selectedMainFeedVO.commentList.add(commentVO);
							}
							if (commentsArray.length() > 0)
								displayCommentsOnUI();
						} catch (Exception e) {
							// TODO: handle exception
							e.printStackTrace();
						}
					}
				}).executeAsync();
		return arr;
	}

	int getDateDifference(Date firstDate, Date secondDate) {
		long diff = firstDate.getTime() - secondDate.getTime();
		long seconds = diff / 1000;
		long minutes = seconds / 60;
		long hours = minutes / 60;
		long days = hours / 24;
		return (int) hours;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.moredetailscreen_main);
		constants = new Constants(MoreDetailScreenActivity.this);
		feedDetailsLayout = (LinearLayout) findViewById(R.id.feedDetailsLayout);
		MoreDetailScreenActivity.this.getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
		toplabletext = (TextView) findViewById(R.id.toplabletext);
		toplabletext.setText(selectedMainFeedVO.username);

		searchEditText = (EditText) findViewById(R.id.search);
		searchEditText
				.setOnEditorActionListener(new TextView.OnEditorActionListener() {
					@Override
					public boolean onEditorAction(TextView v, int actionId,
							KeyEvent event) {
						if (actionId == EditorInfo.IME_ACTION_SEARCH) {
							if (!searchEditText.getText().toString().equals("")) {
								MainFeedListActivity.searchKeyword = searchEditText
										.getText().toString();
								Intent intent = new Intent(
										MoreDetailScreenActivity.this,
										MainFeedListActivity.class);
								startActivity(intent);
							}
							return true;
						}
						return false;
					}
				});

		clearable_button_clear = (Button) findViewById(R.id.clearable_button_clear);
		clearable_button_clear.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				searchEditText.setText("");
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(searchEditText.getWindowToken(), 0);
			}
		});

		// main message textview
		mainMessageTextView = (TextView) findViewById(R.id.mainMessageTextView);
		mainMessageTextView.setTextColor(Color.BLACK);
		mainMessageTextView.setText(selectedMainFeedVO.message);
		TextView picturesTextView = (TextView) findViewById(R.id.picturesTextView);
		if (selectedMainFeedVO.feedImagesList.size() == 0) {
			picturesTextView.setVisibility(View.GONE);
		}

		Button categoryBtn = (Button) findViewById(R.id.btn_categories);
		categoryBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				constants.showCategoryDialogue();
			}
		});

		Button postBtn = (Button) findViewById(R.id.btn_post);
		postBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				constants.showPostDialogue();
			}
		});

		// feed images
		feedImagesLayout = (LinearLayout) findViewById(R.id.feedImagesLayout);
		for (int count = 0; count < selectedMainFeedVO.feedImagesList.size(); count++) {
			final ImageView feedImage = new ImageView(
					MoreDetailScreenActivity.this);
			try {
				StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
						.permitAll().build();

				StrictMode.setThreadPolicy(policy);
				URL url = new URL(selectedMainFeedVO.feedImagesList.get(count));
				Bitmap bmp = BitmapFactory.decodeStream(url.openConnection()
						.getInputStream());
				feedImage.setImageBitmap(bmp);
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}

			feedImage.setLayoutParams(new LayoutParams(200, 140));
			feedImage.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub

					final Dialog dialog = new Dialog(
							MoreDetailScreenActivity.this);
					dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
					dialog.setContentView(R.layout.feedimage);

					ImageView feedimageview = (ImageView) dialog
							.findViewById(R.id.feedimageview);
					feedimageview.setImageBitmap(Bitmap.createScaledBitmap(
							((BitmapDrawable) feedImage.getDrawable())
									.getBitmap(), 300, 300, false));

					ImageView dialogButton = (ImageView) dialog
							.findViewById(R.id.closebtn);

					dialogButton.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							dialog.dismiss();
						}
					});
					dialog.show();
				}
			});

			feedImagesLayout.addView(feedImage);

			feedImagesLayout = (LinearLayout) findViewById(R.id.feedImagesLayout);
			feedImagesLayout.setOnClickListener(new View.OnClickListener() {
				public void onClick(View view) {

					AlertDialog alertDialog = new AlertDialog.Builder(
							MoreDetailScreenActivity.this).create();
					alertDialog.setTitle("");
					alertDialog.setMessage("");

					alertDialog.show();
					alertDialog.getWindow().setLayout(500, 300);// <-- See This!

				}

			});

		}

		if (selectedMainFeedVO.commentList.size() > 0) {
			CommentVO lastcomment = selectedMainFeedVO.commentList
					.get(selectedMainFeedVO.commentList.size() - 1);
			nextCommentsFeedsURL = lastcomment.commentPagingURL;
		}
		displayCommentsOnUI();
	}

	void displayCommentsOnUI() {
		DisplayMetrics metrics = context.getResources().getDisplayMetrics();
		int width = metrics.widthPixels;
		// comments
		commentsLinearLayout = (LinearLayout) findViewById(R.id.commentsLinearLayout);
		commentsLinearLayout.removeAllViews();
		for (int commentscount = 0; commentscount < selectedMainFeedVO.commentList
				.size(); commentscount++) {
			CommentVO cvo = selectedMainFeedVO.commentList.get(commentscount);
			LinearLayout commentMainRelativeLayout = new LinearLayout(
					MoreDetailScreenActivity.this);
			commentMainRelativeLayout.setOrientation(LinearLayout.HORIZONTAL);
			commentMainRelativeLayout.setGravity(Gravity.LEFT);
			LayoutParams commentMainRelativeLayout_LayoutParams = new LayoutParams(
					LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
			commentMainRelativeLayout_LayoutParams.setMargins(0, 10, 0, 10);
			commentMainRelativeLayout
					.setLayoutParams(commentMainRelativeLayout_LayoutParams);
			// comment image user
			SmartImageView commentUserImage = new SmartImageView(
					MoreDetailScreenActivity.this);
			commentUserImage.setBackgroundResource(R.drawable.usericon);
			commentUserImage.setId(100 + commentscount);
			commentUserImage.setImageUrl("https://graph.facebook.com/"
					+ cvo.commentuserid + "/picture?type=large");
			LayoutParams commentUserImage_LayoutParams = new LayoutParams(
					LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);

			commentUserImage_LayoutParams.setMargins(5, 5, 0, 0);
			commentUserImage.setLayoutParams(commentUserImage_LayoutParams);
			commentMainRelativeLayout.addView(commentUserImage);

			// comment username and date relative layout
			LinearLayout usernameDateRelativeLayout = new LinearLayout(
					MoreDetailScreenActivity.this);
			LayoutParams usernameDateRelativeLayout_LayoutParams = new LayoutParams(
					LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);

			usernameDateRelativeLayout_LayoutParams.setMargins(5, 5, 0, 0);
			usernameDateRelativeLayout
					.setLayoutParams(usernameDateRelativeLayout_LayoutParams);
			usernameDateRelativeLayout.setOrientation(LinearLayout.HORIZONTAL);
			usernameDateRelativeLayout.setGravity(Gravity.LEFT);

			// comment username
			TextView usernameTextView = new TextView(
					MoreDetailScreenActivity.this);
			usernameTextView.setTextColor(Color.BLACK);
			usernameTextView.setId(1000 + commentscount);
			LayoutParams usernameTextView_LayoutParams = new LayoutParams(
					width - 350, LayoutParams.WRAP_CONTENT);
			usernameTextView_LayoutParams.setMargins(15, 5, 0, 0);
			usernameTextView.setLayoutParams(usernameTextView_LayoutParams);
			usernameTextView.setTypeface(null, Typeface.BOLD);
			usernameTextView.setText(cvo.commentusername);

			// comment date
			TextView commentDateTextView = new TextView(
					MoreDetailScreenActivity.this);
			android.widget.RelativeLayout.LayoutParams commentDateTextView_LayoutParams = new android.widget.RelativeLayout.LayoutParams(
					200, LayoutParams.WRAP_CONTENT);
			commentDateTextView.setTextColor(Color.BLACK);
			commentDateTextView_LayoutParams.addRule(
					RelativeLayout.ALIGN_PARENT_RIGHT, 1);
			commentDateTextView.setGravity(Gravity.LEFT);
			commentDateTextView.setTypeface(null, Typeface.BOLD);
			commentDateTextView_LayoutParams.addRule(RelativeLayout.RIGHT_OF,
					usernameTextView.getId());
			commentDateTextView_LayoutParams.setMargins(10, 5, 10, 0);
			commentDateTextView
					.setLayoutParams(commentDateTextView_LayoutParams);
			try {
				DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				Date fbdate = format
						.parse(cvo.commentdatetime.split("T")[0]
								+ " "
								+ cvo.commentdatetime.split("T")[1].split(":")[0]
								+ ":"
								+ cvo.commentdatetime.split("T")[1].split(":")[1]);
				Date date = new Date();
				Date todaydate = format.parse(format.format(date));
				int hours = getDateDifference(todaydate, fbdate);
				if (hours <= 1)
					commentDateTextView.setText("Recently");
				if (hours <= 24)
					commentDateTextView.setText(hours + " hrs");
				else {
					commentDateTextView.setText(hours / 24 + " Days Ago");
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}

			// add comment username and date
			usernameDateRelativeLayout.addView(usernameTextView);
			usernameDateRelativeLayout.addView(commentDateTextView);

			// right side linear layout
			LinearLayout rightLinearLayout = new LinearLayout(
					MoreDetailScreenActivity.this);
			LayoutParams rightLinearLayout_LayoutParams = new LayoutParams(
					LinearLayout.LayoutParams.MATCH_PARENT,
					LinearLayout.LayoutParams.WRAP_CONTENT);
			rightLinearLayout_LayoutParams.setMargins(0, 10, 0, 0);
			rightLinearLayout.setLayoutParams(rightLinearLayout_LayoutParams);
			rightLinearLayout.setOrientation(LinearLayout.VERTICAL);

			TextView commentMessageTextView = new TextView(
					MoreDetailScreenActivity.this);
			commentMessageTextView.setPadding(15, 0, 0, 0);
			commentMessageTextView.setLayoutParams(new LayoutParams(
					LinearLayout.LayoutParams.MATCH_PARENT,
					LinearLayout.LayoutParams.WRAP_CONTENT));
			commentMessageTextView.setTextColor(Color.BLACK);
			if (!cvo.commentmessage.equals(""))
				commentMessageTextView.setText(cvo.commentmessage);
			else
				commentMessageTextView.setText("N/A");
			commentMessageTextView.setVerticalScrollBarEnabled(true);
			commentMessageTextView
					.setMovementMethod(new ScrollingMovementMethod());

			rightLinearLayout.addView(usernameDateRelativeLayout);
			rightLinearLayout.addView(commentMessageTextView);
			commentMainRelativeLayout.addView(rightLinearLayout);
			commentsLinearLayout.addView(commentMainRelativeLayout);
		}

		Button postcomment = (Button) findViewById(R.id.buttonpostcomment);

		postcomment.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {

				// custom dialog
				final Dialog dialog = new Dialog(context);
				dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
				dialog.setContentView(R.layout.comment);

				// set the custom dialog components - text, image and button
				final EditText commentEditText = (EditText) dialog
						.findViewById(R.id.edittext);
				ImageView closeImage = (ImageView) dialog
						.findViewById(R.id.closebtn);
				closeImage.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						dialog.dismiss();
					}
				});
				Button dialogButton = (Button) dialog
						.findViewById(R.id.dialogButtonOK);
				// if button is clicked, close the custom dialog
				dialogButton.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						if (!commentEditText.getText().toString().equals("")) {
							postcommentFBdialogue(commentEditText.getText()
									.toString());
							dialog.dismiss();
						} else {
							final Dialog dialog_alert = new Dialog(context);
							dialog_alert
									.requestWindowFeature(Window.FEATURE_NO_TITLE);
							dialog_alert.setContentView(R.layout.common_alert);

							TextView dialogueTextView = (TextView) dialog_alert
									.findViewById(R.id.text);
							dialogueTextView.setText("Please Enter Comment.");

							Button closebtn = (Button) dialog_alert
									.findViewById(R.id.dialogButtonOK);
							closebtn.setOnClickListener(new OnClickListener() {

								@Override
								public void onClick(View v) {
									// TODO Auto-generated method stub
									dialog_alert.dismiss();
								}
							});
							dialog_alert.show();
						}

					}
				});

				dialog.show();
			}
		});
	}

	void postcommentFBdialogue(String comment) {
		Bundle params = new Bundle();
		params.putString("message", comment);
		new Request(Session.getActiveSession(), "/" + selectedMainFeedVO.feedid
				+ "/comments", params, HttpMethod.POST, new Request.Callback() {
			public void onCompleted(Response response) {
				/* handle the result */
				System.out.println(response);
			}
		}).executeAsync();
	}

	public void onBackPressed() {
		Intent intent = new Intent(MoreDetailScreenActivity.this,
				MainFeedListActivity.class);
		startActivity(intent);
	}
}
