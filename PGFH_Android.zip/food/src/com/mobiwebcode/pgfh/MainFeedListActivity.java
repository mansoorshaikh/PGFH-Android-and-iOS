package com.mobiwebcode.pgfh;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import app.tabsample.SmartImageView.NormalSmartImageView;

import com.facebook.HttpMethod;
import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.model.GraphObject;
import com.mobiwebcode.pgfh.VO.CommentVO;
import com.mobiwebcode.pgfh.VO.MainFeedVO;
import com.mobiwebcode.pgfh.xList.XListView;
import com.mobiwebcode.pgfh.xList.XListView.IXListViewListener;

public class MainFeedListActivity extends Activity implements
		IXListViewListener {
	public static final int DIALOG_DOWNLOAD_PROGRESS1 = 1;
	final Context context = this;
	private Button categoryButton, postButton;
	int searchcount = 0, feedcount = 0;
	public static String searchKeyword = "";
	String responseString = null;
	String nextFeedsURL = "";
	public static ArrayList<MainFeedVO> mainFeedList = new ArrayList<MainFeedVO>();
	public static ArrayList<MainFeedVO> currentFeedList = new ArrayList<MainFeedVO>();
	public static ArrayList<MainFeedVO> searchFeedList = new ArrayList<MainFeedVO>();
	XListView list;
	private ProgressDialog mProgressDialog;
	public static String[] categoryList = null;
	String isMerchant = "";
	GPSTracker gps;
	public static Double Latitude, Longutude;
	boolean isGPSEnabled = false;
	boolean isNetworkEnabled = false;

	final private static int DIALOG_LOGIN = 1;
	public static Response userGraphObject = null;
	FrameLayout mainFrameLyout;
	FrameLayout.LayoutParams menuPanelParameters;
	FrameLayout.LayoutParams slidingPanelParameters;
	RelativeLayout mainRelativeLayout;
	LinearLayout.LayoutParams headerPanelParameters;
	LinearLayout.LayoutParams listViewParameters;
	Button menuBtn, clearable_button_clear;
	private boolean isExpanded;
	private DisplayMetrics metrics;
	private RelativeLayout slidingPanel;
	int panelWidth = 0;
	EditText searchEditText;
	ProgressBar progressBar = null;
	Constants constants = null;

	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_DOWNLOAD_PROGRESS1:
			mProgressDialog = new ProgressDialog(this);
			mProgressDialog.setMessage("Processing request, Please wait ...");
			mProgressDialog.setCancelable(false);
			mProgressDialog.show();
			return mProgressDialog;

		default:
			return null;
		}
	}

	private void loadMoreFeeds() {

		if (nextFeedsURL.equals(""))
			nextFeedsURL = "/146877278771592/feed";
		getFacebookFeeds();
	}

	public void onBackPressed() {

	}

	private JSONArray getFacebookFeeds() {
		JSONArray arr = null;

		new Request(Session.getActiveSession(), nextFeedsURL, null,
				HttpMethod.GET, new Request.Callback() {
					public void onCompleted(Response response) {
						/* handle the result */
						int currentfeeds = 0;
						SharedPreferences.Editor editor = getSharedPreferences(
								"myPref", MODE_PRIVATE).edit();
						editor.putString("login", "yes");
						editor.commit();
						System.out.println("response :" + response);
						try {
							GraphObject graphObject = response.getGraphObject();
							JSONObject jso = graphObject.getInnerJSONObject();
							JSONArray facebookfeedsArray = jso
									.getJSONArray("data");
							JSONObject pagingObject = jso
									.getJSONObject("paging");
							nextFeedsURL = pagingObject.getString("next")
									.split("146877278771592")[1];
							nextFeedsURL = "/146877278771592" + nextFeedsURL;

							for (int i = 0; i < facebookfeedsArray.length(); i++) {
								JSONObject jsonObject = facebookfeedsArray
										.getJSONObject(i);

								MainFeedVO facebookfeedvo = new MainFeedVO();
								if (!jsonObject.isNull("message"))
									facebookfeedvo.message = jsonObject
											.getString("message");
								if (!jsonObject.isNull("created_time"))
									facebookfeedvo.feeddatetime = jsonObject
											.getString("created_time");

								if (!jsonObject.isNull("story"))
									facebookfeedvo.story = jsonObject
											.getString("story");

								if (!jsonObject.isNull("id"))
									facebookfeedvo.feedid = jsonObject
											.getString("id");

								if (!jsonObject.isNull("link"))
									facebookfeedvo.sharedLink = jsonObject
											.getString("link");

								if (!jsonObject.isNull("description"))
									facebookfeedvo.description = jsonObject
											.getString("description");

								if (!jsonObject.isNull("picture"))
									facebookfeedvo.feedImagesList
											.add(jsonObject
													.getString("picture"));
								// user details parsing

								JSONObject userdetails = jsonObject
										.getJSONObject("from");
								if (!userdetails.isNull("name"))
									facebookfeedvo.username = userdetails
											.getString("name");
								if (!userdetails.isNull("id"))
									facebookfeedvo.userid = userdetails
											.getString("id");

								// comments parsing
								JSONObject commentsMAinObject = null;
								if (!jsonObject.isNull("comments"))
									commentsMAinObject = jsonObject
											.getJSONObject("comments");
								if (commentsMAinObject != null) {
									JSONArray commentsArray = commentsMAinObject
											.getJSONArray("data");

									for (int commentcount = 0; commentcount < commentsArray
											.length(); commentcount++) {
										JSONObject commentsObject = (JSONObject) commentsArray
												.get(commentcount);
										CommentVO commentVO = new CommentVO();
										if (!commentsObject.isNull("id"))
											commentVO.commentid = commentsObject
													.getString("id");
										if (!commentsObject.isNull("message"))
											commentVO.commentmessage = commentsObject
													.getString("message");
										if (!commentsObject.isNull("picture"))
											commentVO.commentImages.add(commentsObject
													.getString("picture"));
										if (!commentsObject
												.isNull("created_time"))
											commentVO.commentdatetime = commentsObject
													.getString("created_time");

										// comment user details
										JSONObject commentuserdetails = commentsObject
												.getJSONObject("from");
										if (!commentuserdetails.isNull("id"))
											commentVO.commentuserid = commentuserdetails
													.getString("id");
										if (!commentuserdetails.isNull("name"))
											commentVO.commentusername = commentuserdetails
													.getString("name");
										JSONObject commentsPagingObject = commentsMAinObject
												.getJSONObject("paging");
										JSONObject commentsPagingObject_cursors = commentsPagingObject
												.getJSONObject("cursors");
										commentVO.commentPagingURL = "/146877278771592_"
												+ commentVO.commentid
												+ "/comments?access_token="
												+ Session.getActiveSession()
														.getAccessToken()
												+ "&limit=25&after="
												+ commentsPagingObject_cursors
														.getString("after");
										facebookfeedvo.commentList
												.add(commentVO);
									}
								}
								currentfeeds++;
								mainFeedList.add(facebookfeedvo);
							}

							System.out.println("JSON : " + graphObject);
							if (searchEditText.getText().toString().equals("")) {
								CustomList adapter = new CustomList(
										MainFeedListActivity.this, mainFeedList);

								list.setXListViewListener(MainFeedListActivity.this);
								list.setPullLoadEnable(true);
								list.setAdapter(adapter);
								mainRelativeLayout.removeView(progressBar);
							} else {
								final int count = currentfeeds;
								feedcount = feedcount + 10;
								if (feedcount % 500 == 0) {
									final Dialog dialog = new Dialog(context);
									dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
									dialog.setContentView(R.layout.searchalert);

									// set the custom dialog components - text,
									// image and button

									Button dialogButton_yes = (Button) dialog
											.findViewById(R.id.btnYes);
									dialogButton_yes.setText("Yes");
									// if button is clicked, close the custom
									// dialog

									dialogButton_yes
											.setOnClickListener(new OnClickListener() {
												@Override
												public void onClick(View v) {
													searchFeeds(searchKeyword,
															mainFeedList.size()
																	- count);
												}
											});

									Button dialogButton_no = (Button) dialog
											.findViewById(R.id.btnNo);
									// if button is clicked, close the custom
									// dialog
									dialogButton_no
											.setOnClickListener(new OnClickListener() {
												@Override
												public void onClick(View v) {
													dialog.dismiss();
												}
											});

									dialog.show();

								} else {
									searchFeeds(searchKeyword,
											mainFeedList.size() - count);
								}

							}

						} catch (Exception e) {
							// TODO: handle exception
							e.printStackTrace();
						}

					}
				}).executeAsync();
		return arr;
	}

	int getDateDifference(Date firstDate, Date secondDate) {
		long diff = firstDate.getTime() - secondDate.getTime();
		long seconds = diff / 1000;
		long minutes = seconds / 60;
		long hours = minutes / 60;
		long days = hours / 24;
		return (int) hours;
	}

	void searchFeeds(String keyword, int position) {
		for (int feedcount = position; feedcount < mainFeedList.size(); feedcount++) {
			MainFeedVO mainFeedVO = mainFeedList.get(feedcount);
			if (mainFeedVO.message.toLowerCase()
					.contains(keyword.toLowerCase())) {
				searchFeedList.add(mainFeedVO);
				searchcount++;
			}
		}
		if (searchcount >= 10) {
			feedcount = 0;
			currentFeedList = searchFeedList;
			CustomList adapter = new CustomList(MainFeedListActivity.this,
					currentFeedList);

			list.setXListViewListener(MainFeedListActivity.this);
			list.setPullLoadEnable(true);
			list.setAdapter(adapter);
			mainRelativeLayout.removeView(progressBar);
		} else {
			loadMoreFeeds();
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.mainfeedlist_main);
		constants = new Constants(MainFeedListActivity.this);

		mainRelativeLayout = (RelativeLayout) findViewById(R.id.mainRelativeLayout);

		progressBar = new ProgressBar(MainFeedListActivity.this, null,
				android.R.attr.progressBarStyle);

		RelativeLayout.LayoutParams progressBarParams = new LayoutParams(50, 50);
		progressBarParams.addRule(RelativeLayout.CENTER_IN_PARENT);
		progressBar.setLayoutParams(progressBarParams);

		if (constants.isOnline() == false) {
			final Dialog dialog = new Dialog(context);
			dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
			dialog.setContentView(R.layout.nointernetconnection);

			// set the custom dialog components - text, image and button

			Button dialogButton = (Button) dialog
					.findViewById(R.id.dialogButtonOK);
			// if button is clicked, close the custom dialog
			dialogButton.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					dialog.dismiss();
				}
			});

			dialog.show();
		}

		gps = new GPSTracker(MainFeedListActivity.this);
		LocationManager locationManager;
		locationManager = (LocationManager) MainFeedListActivity.this
				.getSystemService(LOCATION_SERVICE);
		isGPSEnabled = locationManager
				.isProviderEnabled(LocationManager.GPS_PROVIDER);

		isNetworkEnabled = locationManager
				.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
		if (gps.canGetLocation()) {

			Latitude = gps.getLatitude();
			Longutude = gps.getLongitude();

		} else {
			if (!isGPSEnabled && !isNetworkEnabled) {

				gps.showSettingsAlert();
			} else {
				AlertDialog.Builder alert = new AlertDialog.Builder(
						MainFeedListActivity.this);
				alert.setTitle("Message");
				alert.setMessage("Gps Service can not find your location plz try latter");
				alert.setPositiveButton("ok",
						new DialogInterface.OnClickListener() {

							public void onClick(DialogInterface dialog,
									int which) {
								// TODO Auto-generated method stub

								dialog.dismiss();
							}
						});

				alert.create().show();
			}
		}

		// search feedsx
		searchEditText = (EditText) findViewById(R.id.search);

		searchEditText
				.setOnEditorActionListener(new TextView.OnEditorActionListener() {
					@Override
					public boolean onEditorAction(TextView v, int actionId,
							KeyEvent event) {
						if (actionId == EditorInfo.IME_ACTION_SEARCH) {
							if (!searchEditText.getText().toString().equals("")) {
								searchFeedList = new ArrayList<MainFeedVO>();
								searchcount = 0;
								feedcount = 0;
								mainRelativeLayout.addView(progressBar);
								InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
								imm.hideSoftInputFromWindow(
										searchEditText.getWindowToken(), 0);
								searchKeyword = searchEditText.getText()
										.toString();
								searchFeeds(searchKeyword, 0);
							} else {
								currentFeedList = mainFeedList;
								CustomList adapter = new CustomList(
										MainFeedListActivity.this,
										currentFeedList);

								list.setXListViewListener(MainFeedListActivity.this);
								list.setPullLoadEnable(true);
								list.setAdapter(adapter);
								InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
								imm.hideSoftInputFromWindow(
										searchEditText.getWindowToken(), 0);

							}

							return true;
						}
						return false;
					}
				});

		clearable_button_clear = (Button) findViewById(R.id.clearable_button_clear);
		clearable_button_clear.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				searchEditText.setText("");
				currentFeedList = mainFeedList;
				CustomList adapter = new CustomList(MainFeedListActivity.this,
						currentFeedList);

				list.setXListViewListener(MainFeedListActivity.this);
				list.setPullLoadEnable(true);
				list.setAdapter(adapter);

				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(searchEditText.getWindowToken(), 0);
			}
		});

		list = (XListView) findViewById(R.id.list);

		list.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(MainFeedListActivity.this,
						MoreDetailScreenActivity.class);
				MoreDetailScreenActivity.selectedMainFeedVO = mainFeedList
						.get(arg2);
				startActivity(intent);
			}
		});
		if (mainFeedList.size() == 0) {
			mainRelativeLayout.addView(progressBar);
			loadMoreFeeds();
			new myTask_registerUser_call().execute("");
		} else {
			if (!searchKeyword.equals("")) {
				mainRelativeLayout.addView(progressBar);
				searchFeeds(searchKeyword, 0);
				feedcount = 0;
				searchcount = 0;
			} else {
				currentFeedList = mainFeedList;
				CustomList adapter = new CustomList(MainFeedListActivity.this,
						currentFeedList);

				list.setXListViewListener(MainFeedListActivity.this);
				list.setPullLoadEnable(true);
				list.setAdapter(adapter);
			}
		}

		metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);
		panelWidth = (int) ((metrics.widthPixels) * 0.75);
		slidingPanel = (RelativeLayout) findViewById(R.id.mainRelativeLayout);
		slidingPanelParameters = (FrameLayout.LayoutParams) slidingPanel
				.getLayoutParams();
		slidingPanelParameters.width = metrics.widthPixels;
		slidingPanel.setLayoutParams(slidingPanelParameters);

		menuBtn = (Button) findViewById(R.id.menuBtn);
		menuBtn.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				if (!isExpanded) {
					isExpanded = true;

					// Expand
					new ExpandAnimation(slidingPanel, panelWidth,
							Animation.RELATIVE_TO_SELF, 0.0f,
							Animation.RELATIVE_TO_SELF, 0.75f, 0, 0.0f, 0, 0.0f);
				} else {
					isExpanded = false;

					// Collapse
					new CollapseAnimation(slidingPanel, panelWidth,
							TranslateAnimation.RELATIVE_TO_SELF, 0.75f,
							TranslateAnimation.RELATIVE_TO_SELF, 0.0f, 0, 0.0f,
							0, 0.0f);

				}
			}
		});

		Button buttontoutismwebsite = (Button) findViewById(R.id.btn_tourismwebsite);

		buttontoutismwebsite.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				menuBtn.performClick();
				Intent intent = new Intent(MainFeedListActivity.this,
						Tourismwebsite.class);
				startActivity(intent);
			}
		});
		Button buttoncompanywebsite = (Button) findViewById(R.id.btn_companywebsite);

		buttoncompanywebsite.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				menuBtn.performClick();
				Intent intent = new Intent(MainFeedListActivity.this,
						WebViewActivity.class);
				startActivity(intent);
			}
		});

		Button buttonmerchantlist = (Button) findViewById(R.id.btn_merchantlist);

		buttonmerchantlist.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				menuBtn.performClick();
				Intent myintent = new Intent(MainFeedListActivity.this,
						MerchantListActivity.class);
				startActivity(myintent);

			}
		});

		Button logoutButton = (Button) findViewById(R.id.btn_logout);
		logoutButton.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				SharedPreferences.Editor editor = getSharedPreferences(
						"myPref", MODE_PRIVATE).edit();
				editor.putString("login", "no");
				editor.commit();
				Session.getActiveSession().close();
				Session.getActiveSession().closeAndClearTokenInformation();
				Intent intent = new Intent(MainFeedListActivity.this,
						LoginActivity.class);
				startActivity(intent);
			}
		});

		MainFeedListActivity.this.getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

		postButton = (Button) findViewById(R.id.btn_post);
		postButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				constants.showPostDialogue();
			}
		});

		// select category

		categoryButton = (Button) findViewById(R.id.btn_categories);

		// add button listener
		categoryButton.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View arg0) {
				constants.showCategoryDialogue();
			}
		});
	}

	public class CustomList extends BaseAdapter {
		private final Activity context;
		private String[] web;
		private Integer[] imageId;
		ArrayList<MainFeedVO> adapterFeedList;

		public CustomList(Activity context, ArrayList<MainFeedVO> mainfeedList_) {
			super();
			this.context = context;
			adapterFeedList = mainfeedList_;
		}

		@Override
		public View getView(final int position, final View view,
				ViewGroup parent) {
			LayoutInflater inflater = context.getLayoutInflater();
			View rowView = inflater.inflate(R.layout.mainfeedview, null, true);

			final MainFeedVO mainFeedVO = adapterFeedList.get(position);
			NormalSmartImageView userImage = (NormalSmartImageView) rowView
					.findViewById(R.id.userimg);
			try {
				if (mainFeedVO.feedImagesList.size() == 0)
					userImage.setImageUrl("https://graph.facebook.com/"
							+ mainFeedVO.userid + "/picture?type=large");
				else
					userImage.setImageUrl(mainFeedVO.feedImagesList.get(0));
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}

			TextView username = (TextView) rowView.findViewById(R.id.username);
			TextView message = (TextView) rowView.findViewById(R.id.message);
			TextView feeddatetime = (TextView) rowView
					.findViewById(R.id.feedsdatetime);
			TextView facebookfeed = (TextView) rowView
					.findViewById(R.id.facebookfeed);

			facebookfeed.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri
							.parse(mainFeedVO.sharedLink));
					startActivity(browserIntent);
				}
			});

			try {
				DateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				Date fbdate = format
						.parse(mainFeedVO.feeddatetime.split("T")[0]
								+ " "
								+ mainFeedVO.feeddatetime.split("T")[1]
										.split(":")[0]
								+ ":"
								+ mainFeedVO.feeddatetime.split("T")[1]
										.split(":")[1]);
				Date date = new Date();
				Date todaydate = format.parse(format.format(date));
				int hours = getDateDifference(todaydate, fbdate);
				if (hours <= 1)
					feeddatetime.setText("Recently");
				if (hours <= 24)
					feeddatetime.setText(hours + " hrs");
				else {
					feeddatetime.setText(hours / 24 + " Days Ago");
				}
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}

			Button moreButton = (Button) rowView.findViewById(R.id.btn_more);
			moreButton.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View arg0) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(MainFeedListActivity.this,
							MoreDetailScreenActivity.class);
					MoreDetailScreenActivity.selectedMainFeedVO = adapterFeedList
							.get(position);
					startActivity(intent);
				}
			});
			String feedmessage = "";
			if (!mainFeedVO.message.equals(""))
				feedmessage = mainFeedVO.message.substring(0,
						Math.min(mainFeedVO.message.length(), 30))
						+ "....";
			else if (!mainFeedVO.description.equals(""))
				feedmessage = mainFeedVO.description.substring(0,
						Math.min(mainFeedVO.description.length(), 30))
						+ "....";
			else
				feedmessage = "N/A";
			if (feedmessage.toLowerCase().startsWith(
					"[ official announcement ]".toLowerCase()))
				message.setText(feedmessage.replace(
						"[ official announcement ]",
						"[ official announcement ]\n"));
			else if (feedmessage.toLowerCase().startsWith(
					"[ admin announcement ]".toLowerCase()))
				message.setText(feedmessage.replace("[ admin announcement ]",
						"[ admin announcement ]\n"));
			else if (feedmessage.toLowerCase().startsWith(
					"[ Admin ]".toLowerCase()))
				message.setText(feedmessage.replace("[ Admin ]", "[ Admin ]\n"));
			else if (feedmessage.toLowerCase().startsWith(
					"[ Official ]".toLowerCase()))
				message.setText(feedmessage.replace("[ Admin ]", "[ Admin ]\n"));
			else {
				message.setText(feedmessage);
				message.setTextColor(Color.BLACK);
			}
			if (!mainFeedVO.story.equals("")) {
				if (mainFeedVO.story.contains("'s post")) {
					username.setMovementMethod(LinkMovementMethod.getInstance());
					username.setText(Html.fromHtml(mainFeedVO.story.replace(
							"post", "<a href=\"" + mainFeedVO.sharedLink
									+ "\">post</a>")));
				} else if (mainFeedVO.story.contains("'s photo")) {
					username.setMovementMethod(LinkMovementMethod.getInstance());
					username.setText(Html.fromHtml(mainFeedVO.story.replace(
							"photo", "<a href=\"" + mainFeedVO.sharedLink
									+ "\">photo</a>")));
				} else if (mainFeedVO.story.contains("album")) {
					username.setMovementMethod(LinkMovementMethod.getInstance());
					username.setText(Html.fromHtml(mainFeedVO.story.replace(
							"album", "<a href=\"\">album</a>")));
				} else {
					username.setText(mainFeedVO.story);
				}
				username.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent browserIntent = new Intent(Intent.ACTION_VIEW,
								Uri.parse(mainFeedVO.sharedLink));
						startActivity(browserIntent);
					}
				});
			} else {
				username.setText(mainFeedVO.username);
				username.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						Intent intent = new Intent(MainFeedListActivity.this,
								MoreDetailScreenActivity.class);
						MoreDetailScreenActivity.selectedMainFeedVO = adapterFeedList
								.get(position);
						startActivity(intent);
					}
				});

			}
			message.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(MainFeedListActivity.this,
							MoreDetailScreenActivity.class);
					MoreDetailScreenActivity.selectedMainFeedVO = adapterFeedList
							.get(position);
					startActivity(intent);
				}
			});

			userImage.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(MainFeedListActivity.this,
							MoreDetailScreenActivity.class);
					MoreDetailScreenActivity.selectedMainFeedVO = adapterFeedList
							.get(position);
					startActivity(intent);
				}
			});

			feeddatetime.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					Intent intent = new Intent(MainFeedListActivity.this,
							MoreDetailScreenActivity.class);
					MoreDetailScreenActivity.selectedMainFeedVO = adapterFeedList
							.get(position);
					startActivity(intent);
				}
			});
			return rowView;

		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return adapterFeedList.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return 0;
		}
	}

	// facebpook feeds async

	class myTask_categoryList_call extends AsyncTask<String, Void, String> {
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		protected String doInBackground(String... aurl) {
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response;
			try {
				response = httpclient.execute(new HttpGet(
						"http://mobiwebcode.com/pgfh/getcategorylist.php"));
				StatusLine statusLine = response.getStatusLine();
				if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
					ByteArrayOutputStream out = new ByteArrayOutputStream();
					response.getEntity().writeTo(out);
					responseString = out.toString();
					if (responseString != null) {
						categoryList = new String[responseString.split("abcd").length];
						categoryList = responseString.split("a1b2c3");
					}
					out.close();
				} else {
					// Closes the connection.
					response.getEntity().getContent().close();
					throw new IOException(statusLine.getReasonPhrase());
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return "";
		}

		protected void onPostExecute(String str_resp) {
			if (mProgressDialog != null)
				mProgressDialog.dismiss();

		}
	}

	// register User call

	class myTask_registerUser_call extends AsyncTask<String, Void, String> {
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		protected String doInBackground(String... aurl) {
			HttpClient httpclient = new DefaultHttpClient();
			HttpResponse response;

			try {
				System.out.println(userGraphObject);
				GraphObject user_graphObject = userGraphObject.getGraphObject();
				JSONObject jso = user_graphObject.getInnerJSONObject();
				response = httpclient.execute(new HttpGet(
						"http://mobiwebcode.com/pgfh/addfacebookuser.php?username="
								+ jso.getString("first_name") + "_"
								+ jso.getString("last_name")
								+ "&facebookuserid=" + jso.getString("id")
								+ "&facebookname="
								+ jso.getString("name").replace(" ", "_")
								+ "&email=laurent@gmail.com"));
				StatusLine statusLine = response.getStatusLine();
				if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
					ByteArrayOutputStream out = new ByteArrayOutputStream();
					response.getEntity().writeTo(out);
					responseString = out.toString();

					out.close();
					if (responseString != null) {
						if (responseString.equals("merchant"))
							isMerchant = "merchant";
						else if (responseString.equals("normal"))
							isMerchant = "normal";
					}

				} else {
					// Closes the connection.
					response.getEntity().getContent().close();
					throw new IOException(statusLine.getReasonPhrase());
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
			return "";
		}

		protected void onPostExecute(String str_resp) {

			if (mProgressDialog != null)
				mProgressDialog.dismiss();

			new myTask_categoryList_call().execute("");
		}
	}

	@Override
	public void onRefresh() {
		// TODO Auto-generated method stub
		searchcount = 0;
		feedcount = 0;
		loadMoreFeeds();
		onLoad();
	}

	@Override
	public void onLoadMore() {
		// TODO Auto-generated method stub
		searchcount = 0;
		feedcount = 0;
		loadMoreFeeds();
		onLoad();
	}

	private void onLoad() {
		list.stopRefresh();
		list.stopLoadMore();
		list.setRefreshTime("刚刚");
	}

}