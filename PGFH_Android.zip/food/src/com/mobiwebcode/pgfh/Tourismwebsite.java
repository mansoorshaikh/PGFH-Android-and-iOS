package com.mobiwebcode.pgfh;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.view.WindowManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Tourismwebsite extends Activity {
	WebView webview;
	Constants constants = null;
	public static String webURL = "";
	EditText searchEditText;
	Button clearable_button_clear;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.webviewactivity);

		searchEditText = (EditText) findViewById(R.id.search);
		searchEditText
				.setOnEditorActionListener(new TextView.OnEditorActionListener() {
					@Override
					public boolean onEditorAction(TextView v, int actionId,
							KeyEvent event) {
						if (actionId == EditorInfo.IME_ACTION_SEARCH) {
							if (!searchEditText.getText().toString().equals("")) {
								MainFeedListActivity.searchKeyword = searchEditText
										.getText().toString();
								Intent intent = new Intent(Tourismwebsite.this,
										MainFeedListActivity.class);
								startActivity(intent);
							}
							return true;
						}
						return false;
					}
				});

		clearable_button_clear = (Button) findViewById(R.id.clearable_button_clear);
		clearable_button_clear.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				searchEditText.setText("");
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(searchEditText.getWindowToken(), 0);
			}
		});

		constants = new Constants(Tourismwebsite.this);
		Button categoryBtn = (Button) findViewById(R.id.btn_categories);
		categoryBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				constants.showCategoryDialogue();
			}
		});

		Button postBtn = (Button) findViewById(R.id.btn_post);
		postBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				constants.showPostDialogue();
			}
		});

		Tourismwebsite.this.getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

		webview = (WebView) findViewById(R.id.webview);
		if (webURL.equals(""))
			webURL = "http://www.tourism.gov.my/en/my";
		webview.setWebViewClient(new WebViewClient());
		webview.loadUrl(webURL);
	}

	public void onBackPressed() {
		Intent intent = new Intent(this, MainFeedListActivity.class);
		startActivity(intent);
	}
}
