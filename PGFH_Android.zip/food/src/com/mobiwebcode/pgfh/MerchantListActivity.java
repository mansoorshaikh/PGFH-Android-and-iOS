package com.mobiwebcode.pgfh;

import java.util.ArrayList;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.mobiwebcode.pgfh.VO.MerchantVO;

import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.LinearLayout.LayoutParams;

public class MerchantListActivity extends Activity {
	String xml = "";
	NodeList nl;
	Document doc;
	XMLParser parser = new XMLParser();
	public static final int DIALOG_DOWNLOAD_PROGRESS1 = 1;
	private ProgressDialog mProgressDialog;
	ArrayList<MerchantVO> merchantList = new ArrayList<MerchantVO>();
	String MERCHANT_LIST_URL = "http://mobiwebcode.com/PGFH/merchantlist.php";
	LinearLayout merchantLinearLayout;
	Constants constants = null;
	EditText searchEditText;
	Button clearable_button_clear;

	protected Dialog onCreateDialog(int id) {
		switch (id) {
		case DIALOG_DOWNLOAD_PROGRESS1:
			mProgressDialog = new ProgressDialog(this);
			mProgressDialog.setMessage("Loading, please wait ...");
			mProgressDialog.setCancelable(false);
			mProgressDialog.show();
			return mProgressDialog;

		default:
			return null;
		}
	}

	class myTask_fetch_musicnews_call extends AsyncTask<String, Void, String> {
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			onCreateDialog(DIALOG_DOWNLOAD_PROGRESS1);
		}

		protected String doInBackground(String... aurl) {
			try {

				xml = parser.getXmlFromUrl(MERCHANT_LIST_URL);
				doc = parser.getDomElement(xml); // getting
				if (doc != null) {
					nl = doc.getElementsByTagName("merchant");
					merchantList.clear();
					// looping through all item nodes <item>
					for (int i = 0; i < nl.getLength(); i++) {
						Element e = (Element) nl.item(i);
						MerchantVO mvo = new MerchantVO();
						mvo.merchantid = parser.getValue(e, "merchantid");
						mvo.merchantname = parser.getValue(e, "merchantname");
						mvo.merchantdescription = parser.getValue(e,
								"merchantdescription");
						merchantList.add(mvo);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return "";
		}

		protected void onPostExecute(String str_resp) {
			try {
				fillUI();
				if (mProgressDialog != null)
					mProgressDialog.dismiss();
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
		}
	}

	void fillUI() {
		try {
			merchantLinearLayout = (LinearLayout) findViewById(R.id.merchantLinearLayout);
			merchantLinearLayout.removeAllViews();
			for (int merchantcount = 0; merchantcount < merchantList.size(); merchantcount++) {
				MerchantVO merchantVO = merchantList.get(merchantcount);
				// merchant linear layout
				LinearLayout merchantInfoLinearLayout = new LinearLayout(
						MerchantListActivity.this);
				merchantInfoLinearLayout.setOrientation(LinearLayout.VERTICAL);
				LayoutParams merchantInfoLinearLayout_LayoutParams = new LayoutParams(
						LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
				merchantInfoLinearLayout_LayoutParams.setMargins(5, 5, 5, 5);
				merchantInfoLinearLayout
						.setLayoutParams(merchantInfoLinearLayout_LayoutParams);

				// Merchant name textview
				TextView merchantnameTextView = new TextView(
						MerchantListActivity.this);
				merchantnameTextView.setTypeface(null, Typeface.BOLD);
				merchantnameTextView.setTextColor(Color.parseColor("#00C5CD"));
				merchantnameTextView.setText(merchantVO.merchantname);
				LayoutParams merchantnameTextView_LayoutParams = new LayoutParams(
						LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
				merchantnameTextView_LayoutParams.setMargins(5, 0, 0, 5);
				merchantnameTextView
						.setLayoutParams(merchantnameTextView_LayoutParams);

				// merchant description text view
				TextView merchantdescriptionTextView = new TextView(
						MerchantListActivity.this);
				merchantdescriptionTextView.setTypeface(null, Typeface.BOLD);
				merchantdescriptionTextView.setTextColor(Color.BLACK);
				merchantdescriptionTextView
						.setText(merchantVO.merchantdescription);
				LayoutParams merchantdescriptionTextView_LayoutParams = new LayoutParams(
						LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
				merchantdescriptionTextView_LayoutParams.setMargins(5, 0, 0, 5);
				merchantdescriptionTextView
						.setLayoutParams(merchantdescriptionTextView_LayoutParams);

				merchantInfoLinearLayout.addView(merchantnameTextView);
				merchantInfoLinearLayout.addView(merchantdescriptionTextView);

				merchantLinearLayout.addView(merchantInfoLinearLayout);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.merchantlist);
		constants = new Constants(MerchantListActivity.this);
		MerchantListActivity.this.getWindow().setSoftInputMode(
				WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);

		searchEditText = (EditText) findViewById(R.id.search);
		searchEditText
				.setOnEditorActionListener(new TextView.OnEditorActionListener() {
					@Override
					public boolean onEditorAction(TextView v, int actionId,
							KeyEvent event) {
						if (actionId == EditorInfo.IME_ACTION_SEARCH) {
							if (!searchEditText.getText().toString().equals("")) {
								MainFeedListActivity.searchKeyword = searchEditText
										.getText().toString();
								Intent intent = new Intent(
										MerchantListActivity.this,
										MainFeedListActivity.class);
								startActivity(intent);
							}
							return true;
						}
						return false;
					}
				});

		clearable_button_clear = (Button) findViewById(R.id.clearable_button_clear);
		clearable_button_clear.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				searchEditText.setText("");
				InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
				imm.hideSoftInputFromWindow(searchEditText.getWindowToken(), 0);
			}
		});

		Button categoryBtn = (Button) findViewById(R.id.btn_categories);
		categoryBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				constants.showCategoryDialogue();
			}
		});

		Button postBtn = (Button) findViewById(R.id.btn_post);
		postBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				constants.showPostDialogue();
			}
		});

		new myTask_fetch_musicnews_call().execute("");
	}

	void parseMechantList() {

	}

	public void onBackPressed() {
		Intent intent = new Intent(this, MainFeedListActivity.class);
		startActivity(intent);
	}
}
