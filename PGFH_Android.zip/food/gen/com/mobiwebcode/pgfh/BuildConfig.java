/** Automatically generated file. DO NOT MODIFY */
package com.mobiwebcode.pgfh;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}