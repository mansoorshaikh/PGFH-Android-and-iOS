<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
<script language="JavaScript" src="date.format.js" type="text/javascript"></script>
<script language="JavaScript" src="htmlDatePicker.js" type="text/javascript"></script>
<link href="htmlDatePicker.css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery.js"></script>
<script src="js/common.js" language="javascript"></script>

<?php
    include('include/header.php');
    ?>
<script language="javascript" type="text/javascript">

function validUpdate()
{
	return validate_page('tname,blank,Please enter name.');
}

function onEventChange(var1){
    document.getElementById("events").value=var1;
}

function validateFields(){
    if(document.getElementById('sourcename').value=="" ){
        alert('Please fill in Source Name');
    }
    else{
        var sourcename=document.getElementById('sourcename').value;
        $.ajax({
               type: "POST",
               url: "../CheckSourceExists.php",
               data: "sourcename="+sourcename,
               success: function(msg){
               if(parseInt(msg)==101)
               {
               alert("updatesourcefunction.php?sourcename="+sourcename+"&sourceid="+getParameterByName('sourceid'));
                    window.location.href = "updatesourcefunction.php?sourcename="+sourcename+"&sourceid="+getParameterByName('sourceid');
               }
               else
               {
               alert('Source Name Already Exists, please Add new source!!!');
               document.getElementById('u').focus();
               return false;
               }
               }
               });
    }
}

function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
    results = regex.exec(location.search);
    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}


</script>
</head><body>
<form method="post" name="theForm" enctype="multipart/form-data">
<table class="forumline" style="width: 100%;" cellpadding="8" cellspacing="0">
<tbody>
<tr>
<td class="row-header" colspan="2">EDIT SOURCE DETAILS</td>
</tr>
<tr>
<td colspan="2" align="left">
<a href="sourceslist.php" title="Back " style="font-weight:bold;text-decoration:none;" >&laquo; Back</a>
</td>
</tr>

<tr id="TRusername">
<td class="row1" style="text-align: right;">Source name:</td>
<td class="row1">
<input name="sourcename" id="sourcename" type="text" value="<?php echo $_REQUEST['sourcename'] ?>">
</td>
</tr>

<tr id="TRusername">
<td class="row1" style="text-align: right;"></td>
<td class="row1"><input name="submit" value="Submit" align="left" type="button" onclick="validateFields()"></td>
</tr>



</tbody></table>

</form>

</body></html>