<?PHP
ob_start();
session_start();
$_SESSION['adminId']=1;
require_once('../pi_classes/Admin.php');
$objAdmin=new Admin();
$updateFlag=false;
if(isset($_POST['email']))
{
	$flag=$objAdmin->updateAdminDetails($_SESSION['adminId'],$_POST['email']);		
	$updateFlag=$flag;
}

$objAdmin->getAdminDetails($_SESSION['adminId']);
$objAdmin->getRow();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
<?php
include('include/header.php');
?>
<script language="javascript" type="text/javascript">
function validUpdate()
{
	return validate_page('email,blank,Please enter Email Id.','email,email_chk,Please enter valid email Id.');
}
</script>
</head><body>
<form method="post" name="theForm" action="<?php echo $_SERVER['PHP_SELF']?>">
<table class="forumline" style="width: 100%;" cellpadding="8" cellspacing="0">
<tbody>
<tr>
    <td class="row-header" colspan="2">Update Admin Details </td>
</tr>
<tr> 
    <td class="message_info" colspan="2" align="center">
    <?php
		if($updateFlag)
		{
			echo 'You have sucessfully updated admin details.';	
		}
		if($_GET['msg']==md5('changePassword'))
		{
			echo 'You have sucessfully changed password.';	
		}
	?>
	</td> 
</tr>

<tr id="TRusername">
  <td class="row1" style="text-align: right;">User Name:*</td>
  <td class="row1"><input readonly="readonly" name="username" id="username" value="<?php echo $objAdmin->getField('username');?>" type="text">
    <span style="padding-left: 15px;">
	  <a href="changePassword.php" class="thickbox">Change Password</a>
	</span></td>
</tr>
<tr id="TRusername">
  <td class="row1" style="text-align: right;">Email:*</td>
  <td class="row1"><input name="email" id="email" value="<?php echo $objAdmin->getField('email_id');?>" type="text">
    </td>
</tr>

<tr id="TRusername">
  <td class="row1" style="text-align: right;">Last Updated On: </td>
  <td class="row1"><?php echo $objAdmin->getField('updated_on');?></td>
</tr>
<tr id="TRusername">
  <td class="row1" style="text-align: right;">Last Logged in: </td>
  <td class="row1"><?php echo $objAdmin->getField('login_on');?></td>
</tr>
<tr id="TRusername">
  <td class="row1" style="text-align: right;"></td>
  <td class="row1"><input name="submit" value="Submit" onClick="javascript:return validUpdate()" align="left" type="submit"></td>
</tr>

</tbody></table>

</form>

</body></html>