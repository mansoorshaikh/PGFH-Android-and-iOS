<?PHP
ob_start();
session_start();
require_once('../pi_classes/Admin.php');
    
if(isset($_POST['userName']) AND isset($_POST['password'])) 
{
	$objAdmin=new Admin();
	$objAdmin->chkLoginDetails($_POST['userName'],$_POST['password']);
	if($objAdmin->getRow())
	{
		$_SESSION['adminId']=$objAdmin->getField('adminid');
		echo 101;
		
        exit;
	}else{
        echo 100;
    }
}
	
?>