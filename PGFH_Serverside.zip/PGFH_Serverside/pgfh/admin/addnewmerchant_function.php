<?PHP
    require_once('../pi_classes/Town.php');
    $objTown=new Town();
    $sourceid=$objTown->addmerchant_function($_REQUEST['merchantname'],$_REQUEST['merchantdesc']);
	echo 101;
    ?>