<?PHP
    require_once('../pi_classes/Town.php');
    $objTown=new Town();
    $sourceid=$objTown->addcategory_function($_REQUEST['categoryname']);
	echo 101;
    ?>