<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>


<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta http-equiv="cache-control" content="no-cache">
</head><body class="top_nav">
<table style="width: 100%; padding-top: 2px;">
<tbody><tr>
	<td width="25%" align="left"><a href="index.php" target="_parent"><!--<img src="../images/canadavisa-logo-web.jpg" border="0">--></a></td>
	<td style="vertical-align: middle;" width="50%" align="center"><strong>Administration Panel</strong></td>
	<td style="text-align: right; vertical-align: middle;" width="25%">
	<span>Welcome <b>admin</b></span>
	<span>| <a href="logout.php" target="_top">LOGOUT</a></span>	</td>
</tr>
</tbody>
</table>

</body></html>