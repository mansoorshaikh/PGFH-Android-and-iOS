<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
<script language="JavaScript" src="date.format.js" type="text/javascript"></script>
<script language="JavaScript" src="htmlDatePicker.js" type="text/javascript"></script>
<link href="htmlDatePicker.css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery.js"></script>
<script src="js/common.js" language="javascript"></script>

<?php
include('include/header.php');
?>
<script language="javascript" type="text/javascript">

function validUpdate()
{
	return validate_page('tname,blank,Please enter name.');
}

function onEventChange(var1){
    document.getElementById("events").value=var1;
}

function validateFields(){
    if(document.getElementById('rodeoname').value=="" || document.getElementById('location').value=="" || document.getElementById('rodeostartdate').value=="" || document.getElementById('numberofrounds').value==""){
        alert('Please fill in all the fields');
    }else if(isNaN(document.getElementById('numberofrounds').value)){
        alert('Number of rounds should be number');
    }else if(document.getElementById('location').value.indexOf(",") == -1){
        alert('Please Enter Location in Lattitide,Longitude Format');
    }
    else{
        var rodeoname=document.getElementById('rodeoname').value;
        var location=document.getElementById('location').value;
        var rodeostartdate=document.getElementById('rodeostartdate').value;
        var numberofrounds=document.getElementById('numberofrounds').value;
        
        $.ajax({
               type: "POST",
               url: "../CheckRodeoExists.php",
               data: "rodeoname="+rodeoname,
               success: function(msg){
               if(parseInt(msg)==101)
               {
                    window.location.href = SITE_URL+"/addrodeo.php?rodeoname="+rodeoname+"&location="+location+"&rodeostartdate="+rodeostartdate+"&numberofrounds="+numberofrounds;
               }
               else
               {
               alert('Rodeo Name Already Exists');
               document.getElementById('u').focus();
               return false;
               }
               }
    });
    }
}

</script>
</head><body>
<form method="post" name="theForm" enctype="multipart/form-data">
<table class="forumline" style="width: 100%;" cellpadding="8" cellspacing="0">
<tbody>
<tr>
    <td class="row-header" colspan="2">ADD RODEO DETAILS</td>
</tr>
<tr> 
    <td colspan="2" align="left">
   	<a href="rodeolist.php" title="Back " style="font-weight:bold;text-decoration:none;" >&laquo; Back</a>
	</td> 
</tr>

<tr id="TRusername">
  <td class="row1" style="text-align: right;">Rodeo name:</td>
  <td class="row1">
  		<input name="rodeoname" id="rodeoname" type="text">
   </td>
</tr>

<tr id="TRusername">
<td class="row1" style="text-align: right;">Location:</td>
<td class="row1">
<input name="location" id="location" type="text">
Please Enter Location in Lattitude,Longitude Format</td>
</tr>


<tr id="TRusername">
<td class="row1" style="text-align: right;">Date:</td>
  <td class="row1">
  		<input type="text" name="rodeostartdate" id="rodeostartdate" readonly onClick="GetDate(this);" />
   </td>
</tr>

<tr id="TRusername">
<td class="row1" style="text-align: right;">Number of Rounds:</td>
<td class="row1">
<input name="numberofrounds" id="numberofrounds" size="20" type="text">
</td>
</tr>


<tr id="TRusername">
<td class="row1" style="text-align: right;"></td>
<td class="row1"><input name="submit" value="Submit" align="left" type="button" onclick="validateFields()"></td>
</tr>



</tbody></table>

</form>

</body></html>