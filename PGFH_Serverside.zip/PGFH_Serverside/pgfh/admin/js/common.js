// JavaScript Document
var CurrTopImage=0;
var CurrMiddle1Image=0;
var CurrMiddle2Image=0;
var CurrBottomImage=0;

var MyTopIMG= new Array();
var MyMiddle1IMG=new Array();
var MyMiddle2IMG=new Array();
var MyBottomIMG=new Array();

var MyTopIMGURL= new Array();
var MyMiddle1IMGURL=new Array();
var MyMiddle2IMGURL=new Array();
var MyBottomIMGURL=new Array();

function sendRequest(varURL,varObj)
{
	varObj.open("GET", varURL, true); 
	varObj.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"); 
	varObj.send(null); 
}	
function createObject(varobj)
{
	if(window.XMLHttpRequest)
		varobj = new XMLHttpRequest(); 
	else if (window.ActiveXObject)
		varobj = new ActiveXObject("Microsoft.XMLHTTP");
	return varobj;
}
function IsEmail(Ctrl)
{
    var Expression=Ctrl.value;
	var rep= /^[a-zA-Z]+[ ?]*$/;
	var reEmail =/^[a-z]+(([a-z_0-9]*)|([a-z_0-9]*\.[a-z_0-9]+)|([a-z_0-9]*\-[a-z_0-9]+))*@([a-z_0-9\-\.]+)((\.[a-z]{3})|((\.[a-z]{2})+)|(\.[a-z]{3}(\.[a-z]{2})+))$/;
	if(!reEmail.test(Expression))
	{
		alert(Expression+" is not valid address.\nPlease enter a valid Email Address");
		return false;
	}
		return true;
}

function trim(ctrl,msg)
{
	
title1=ctrl.value;
trimtitle=title1.replace(/^\s+/g,'').replace(/\s+$/g,'');

if(trimtitle.length<=0 || title1=="")
{
	alert(msg);
	ctrl.value='';
	ctrl.focus();
	return false;
}
	return true;
}

function IsNumeric(Expression)
{
        Expression = Expression.toLowerCase();
        RefString = "0123456789 ";

        if (Expression.length < 1)
                return (false);

        for (var i = 0; i < Expression.length; i++)
        {
                var ch = Expression.substr(i, 1)
                var a = RefString.indexOf(ch, 0)
                if (a == -1)
                        return (false);
        }
        return(true);
}

function validatePage()
{
	var MyArg=validatePage.arguments;
//alert(MyArg);	
var valid=true;

	for(arg=0;arg<MyArg.length;arg++)
	{

		arrArgs=MyArg[arg].split(",");
		//alert(arrArgs);
	

if(!trim(getElement(arrArgs[0]),arrArgs[2]) && (arrArgs[1]!="checkbox"))
		{
			valid=false;
			break;
		}
		
		if(arrArgs[1]=="num" && !IsNumeric(getElement(arrArgs[0])))
		{
			valid=false;
			break;
		}
		
		if(arrArgs[1]=="email" && !IsEmail(getElement(arrArgs[0])))
		{
			valid=false;
			break;
		}
		
		if(arrArgs[1]=="checkbox" && !isChecked(arrArgs[0],arrArgs[2]))
		{
			valid=false;
					
			break;
		}

		

		
		
	}

return valid;
}

function isChecked(arg1,arg2)
{
	var totEle=document.getElementsByName(arg1);
	var chk=false;
	
	for(i=0;i<totEle.length;i++)
	{
		if(totEle[i].checked)	
		{
			chk=true;
		}
	}
	
	if(!chk)
	{
		alert(arg2);
	}
	
	return chk;
}

function AllowOnly(Expression,e)
{


if(!e)
{
e=window.event;
}


	if(document.all)
	{
	k=e.keyCode;
	}
	else
	{
	k=e.charCode;
	}
	if(k!=0)
	{
		
		if(!k)
		{
			k=e.keyCode;
		}
		//alert(k);
		switch(k)
		{
			case 13:
			k=0;
			break;
			case 36:
			k=0;
			break;
			case 35:
			k=0;
			break;
			case 8:
			k=0;
			break;
			case 9:
			k=0;
			break;
			case 16:
			k=0;
			break;
			case 46:
			k=0;
			break;
			case 39:
			k=0;
			break;
			case 37:
			k=0;
			break;
			case 82:
			k=0;
			break;
			case 17:
			k=0;
			break;
			default:
			alert(k);
			break;
		}
	}

var ch = String.fromCharCode(k);

        ch = ch.toLowerCase();
        Expression = Expression.toLowerCase();
        var a = Expression.indexOf(ch);
        if (a == -1)
      {
	   
		if(k==0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
		
	return true;

}

function getElement(id)
{
	return document.getElementById(id);
}

function IsDate(dateStr)
{
        // Checks for the following valid date formats:
        // MM/DD/YYYY   MM-DD-YYYY

        var datePat = /^(\d{1,2})(\/|-)(\d{1,2})\2(\d{4})$/;

        var matchArray = dateStr.match(datePat)
        if (matchArray == null)
                return false

        month = matchArray[1]
        day = matchArray[3]
        year = matchArray[4]
        if (month < 1 || month > 12)
                return false

        if (day < 1 || day > 31)
                return false

        if ((month==4 || month==6 || month==9 || month==11) && day==31)
                return false

        if (month == 2)
        {
                var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0))
                if (day>29 || (day==29 && !isleap))
                        return false;
        }
        return true;
}

function Center(url,w,h)
{
   var l = Math.floor((screen.width-w)/2);
   var t = Math.floor((screen.height-h)/2);
   window.open(url,"pop","width=" + w + ",height=" + h + ",top=" + t + ",left=" + l);
}

function closeWindow()
{
     if (navigator.appName=="Microsoft Internet Explorer")
     {
         this.focus();
         self.opener = this;
         self.close();
     }
     else
     {
         window.open('', '_parent', '');
         window.close();
     }
}


function setChanginEvent()
{		
			if(MyTopIMG.length>0)
			{
				setInterval("ChangingTopImages()",5000);
			}
			
			if(MyMiddle1IMG.length>0)
			{
				setInterval("ChangingMiddle1Images()",5000);
			}
			
			if(MyMiddle2IMG.length>0)
			{
				setInterval("ChangingMiddle2Images()",5000);
			}
			
			if(MyBottomIMG.length>0)
			{
				setInterval("ChangingBottomImages()",5000);
			}
			
			
}

function AllowOnly(Expression,e)
{


if(!e)
{
e=window.event;
}


	if(document.all)
	{
	k=e.keyCode;
	}
	else
	{
	k=e.charCode;
	}
	if(k!=0)
	{
		
		if(!k)
		{
			k=e.keyCode;
		}
		//alert(k);
		switch(k)
		{
			case 13:
			k=0;
			break;
			case 36:
			k=0;
			break;
			case 35:
			k=0;
			break;
			case 8:
			k=0;
			break;
			case 9:
			k=0;
			break;
			case 16:
			k=0;
			break;
			case 46:
			k=0;
			break;
		/*	case 116:
			k=0;
			break;*/
			case 82:
			k=0;
			break;
			case 17:
			k=0;
			break;
			default:
			//alert(k);
			break;
		}
	}

var ch = String.fromCharCode(k);

        ch = ch.toLowerCase();
        Expression = Expression.toLowerCase();
        var a = Expression.indexOf(ch);
        if (a == -1)
      {
	   
		if(k==0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
		
	return true;

}

