<?PHP
    require_once('../pi_classes/Town.php');
    $objTown=new Town();
    $objTown->updateUserInfoFunction($_REQUEST['userdescription'],$_REQUEST['userid']);
    
    echo 101;
    ?>