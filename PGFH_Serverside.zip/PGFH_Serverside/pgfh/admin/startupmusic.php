<?php
	require_once("../pi_classes/Town.php");
	
	$objTown=new Town();
	$objTown1=new Town();
	
	$objTown1->getCategoryCount();
	$objTown1->getRow();
	$totalRecord=$objTown1->getField('cnt');
	$limit=10;
	$totalpages=ceil($totalRecord/$limit);
	$currentpage=1;
	if(isset($_GET['pid']))
	{
	$currentpage=($_GET['pid']-1)*$limit;
	}
	else
	{
	$currentpage=0;
	}
	
	$objTown->getAllStory($currentpage,$limit);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
<title>MANAGE Town</title>

<?php
include('include/header.php');
?>
<script>
	function deleteClipCat(id)
	{
		if(confirm('Do you really want to delete this category.'))
		{
		location.href='deleteClipartCat.php?catId='+id;
		return;
		}
	}
	function delProductInfo(id)
	{
		if(confirm('Are you sure you want to delete this category'))
	{ 
		var Host='<?php echo AbstractDB::SITE_PATH; ?>';
		
		$.ajax({
			type: "post",
			url: "ajax/ajaxrequest.php",
			data: "sr="+id+"&name=mastershow",
			success:function(msg) {	
		//	alert(msg);
			window.location.reload();
			}
		});
	}	
	}

</script>
</head><body>
<center><b><font color="#ff0000">
</font></b></center>
<table style="width: 100%;" class="forumline" cellspacing="0">
<tbody>
<tr>
<td class="row-header" colspan="2"><span>StartUp Stream </span></td>
</tr>

<tr> 
	<td class="message_info" colspan="2" align="center">
   	<?php
		switch($_GET['msg'])
		{
			case md5('add'):
				echo 'You have sucessfully added product details';
			break;
			case md5('update'):
				echo 'You have sucessfully updated product details';
			break;		
			case md5('delete'):
				echo 'You have sucessfully deleted product';
			break;
		}
	?>
	</td> 
</tr>


<tr><td>&nbsp;
<center><b><font color="#ff0000">
</font></b></center>

</td></tr>
<tr>
<td colspan="2" align="left"><font size="2"><b> <a href="add_startup.php" title="Add Product Details" style="text-decoration:none;font-weight:bold;">Add StartUp Music &raquo;</a></b></font> </td>
</tr>
<tr><td>&nbsp;</td></tr>

<tr>
<td>
<?php 
for($i=1;$i<=$totalpages;$i++){ ?>
<a href="startupmusic.php?pid=<?php echo $i; ?>"><?php echo $i; ?></a> |
<?php } ?>
</td>
</tr>

<tr>
	<td class="row1" colspan="2">
	<center>
	<table style="width: 700px;">
	<tbody>

<tr>
	<th width="50">Sr.No</th>
	<th width="200">Audio File</th>
</tr>

<?php
$i=0;
while($objTown->getRow())
{
?>
<tr>
	<td class="row1" style="font-size: 9pt;text-align:center;">
		<?php echo ++$i; ?>
    </td>

	<td class="row1" style="font-size: 9pt;">
    	<?PHP echo $objTown->getField('name'); ?>
    </td>
	 
   
</tr>
<?php
}
?>
</tbody>
</table>
</center>
</td>
</tr>

<script type="text/javascript" src="http://mediaplayer.yahoo.com/js"></script>
</tbody></table></body></html>