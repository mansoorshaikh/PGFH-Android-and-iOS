<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="stylesheet" href="css/admin.css" type="text/css">
<meta http-equiv="cache-control" content="no-cache">
<script type="text/javascript" src="js/jquery.js"></script>
<script src="js/common.js" language="javascript"></script>
<script src="js/menuswap.js" language="javascript"></script>
<link rel="stylesheet" type="text/css" href="style.css" />