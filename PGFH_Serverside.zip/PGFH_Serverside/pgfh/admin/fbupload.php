<?php
session_start();
require_once("../pi_classes/Town.php");
require_once 'facebook-php-sdk/autoload.php';
use Facebook\FacebookSession;
use Facebook\FacebookRequest;
use Facebook\GraphUser;
use Facebook\FacebookRequestException;
use Facebook\FacebookRedirectLoginHelper;

$api_key = '338821176236573';
$api_secret = 'ec09238dfd948b6e53222d75acc68d29';
$redirect_login_url = 'http://mobiwebcode.com/pgfh/admin/fbupload.php';



// https://www.webniraj.com/2014/05/01/facebook-api-php-sdk-updated-to-v4-0-0/
$objTown=new Town();
$objTown2=new Town();
$objTown2->updateAdvtPostFunction();
$objTown->getAdvtPostListFunction();
echo $_REQUEST['advtpostid'];
while($objTown->getRow()){
	echo 'advtpostid : '.$objTown->getField('advtpostid');
	if($objTown->getField('advtpostid')==$_REQUEST['advtpostid']){
	$facebookmessage="Outlet : ".$objTown->getField('outlet')."\nLocation : ".$objTown->getField('location')."\nLatitude : ".$objTown->getField(
	'latitude')."\nLongitude : ".$objTown->getField('longitude')."\nContact : ".$objTown->getField('contact')."\nDescription : ".$objTown->getField(
	'description');
	break;
	}
}
echo $facebookmessage;
if($_REQUEST['status']=='approved'){

// initialize your app using your key and secret
FacebookSession::setDefaultApplication($api_key, $api_secret);

// create a helper opject which is needed to create a login URL
// the $redirect_login_url is the page a visitor will come to after login
$helper = new FacebookRedirectLoginHelper( $redirect_login_url);


// First check if this is an existing PHP session
if ( isset( $_SESSION ) && isset( $_SESSION['fb_token'] ) ) {
	// create new session from the existing PHP sesson
	$session = new FacebookSession( $_SESSION['fb_token'] );
	try {
		// validate the access_token to make sure it's still valid
		if ( !$session->validate() ) $session = null;
	} catch ( Exception $e ) {
		// catch any exceptions and set the sesson null
		$session = null;
		echo 'No session: '.$e->getMessage();
	}
}  elseif ( empty( $session ) ) {
	// the session is empty, we create a new one
	try {
		// the visitor is redirected from the login, let's pickup the session
		$session = $helper->getSessionFromRedirect();
	} catch( FacebookRequestException $e ) {
		// Facebook has returned an error
		echo 'Facebook (session) request error: '.$e->getMessage();
	} catch( Exception $e ) {
		// Any other error
		echo 'Other (session) request error: '.$e->getMessage();
	}
}
if ( isset( $session ) ) {
	// store the session token into a PHP session
	$_SESSION['fb_token'] = $session->getToken();
	// and create a new Facebook session using the cururent token
	// or from the new token we got after login
	$session = new FacebookSession( $session->getToken() );
	try {
		// with this session I will post a message to my own timeline
		$request = new FacebookRequest(
			$session,
			'POST',
			'/146877278771592/feed',
			array(
				'link' => 'www.mobiwebcode.com/pgfh/admin/'.$objTown->getField('image'),
				'message' => $facebookmessage
			)
		);
		$response = $request->execute();
		$graphObject = $response->getGraphObject();
		// the POST response object
		echo '<pre>' . print_r( $graphObject, 1 ) . '</pre>';
		$msgid = $graphObject->getProperty('id');
		echo '<meta http-equiv="refresh" content="0;url=manageadvtpost.php">';
	} catch ( FacebookRequestException $e ) {
		// show any error for this facebook request
		echo 'Facebook (post) request error: '.$e->getMessage();
	}
	// now we create a second request to get the posted message in return
	if ( isset ( $msgid ) ) {
		// we only need to the sec. part of this ID
		$parts = explode('_', $msgid);
		try {
			$request2 = new FacebookRequest(
				$session,
				'GET',
				'/'.$parts[1]
			);
			$response2 = $request2->execute();
			$graphObject2 = $response2->getGraphObject();
		
			// the GET response object
			echo '<pre>' . print_r( $graphObject2, 1 ) . '</pre>';
			

			
		} catch ( FacebookRequestException $e ) {
			// show any error for this facebook request
			echo 'Facebook (get) request error: '.$e->getMessage();
		}
	}
} else {
	// we need to create a new session, provide a login link
	echo 'No session, please <a href="'. $helper->getLoginUrl( array( 'publish_actions','user_groups' ) ).'">login</a>.';
}
}else{
	echo '<meta http-equiv="refresh" content="0;url=manageadvtpost.php">';
}

// use this for testing only
//unset($_SESSION['fb_token']);
