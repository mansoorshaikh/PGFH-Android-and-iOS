<?php
	require_once("../pi_classes/Town.php");
	
	$objTown=new Town();
    
    ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
<script language="JavaScript" src="date.format.js" type="text/javascript"></script>
<script language="JavaScript" src="htmlDatePicker.js" type="text/javascript"></script>
<link href="htmlDatePicker.css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery.js"></script>
<script src="js/common.js" language="javascript"></script>

<?php
    include('include/header.php');
    ?>
<script language="javascript" type="text/javascript">

function validUpdate()
{
	return validate_page('tname,blank,Please enter name.');
}

function onEventChange(var1){
    document.getElementById("events").value=var1;
}

function validateFields(){
    if(document.getElementById('merchantname').value=="" ){
        alert('Please fill in Proper information to update');
    }
    else{
        var merchantname=document.getElementById('merchantname').value;
		var userdescription=document.getElementById('userdescription').value;
        $.ajax({
               type: "POST",
               url: "updatemerchantinfo_function.php",
               data: "merchantname="+merchantname+"&merchantid="+getQueryVariable('merchantid')+"&merchantdesc="+userdescription,
               success: function(msg){
               if(parseInt(msg)==101)
               {
                   alert('Merchant Information updated successfully');
                    return false;
               }
               }
               });
    }
}

function getQueryVariable(variable) {
  var query = window.location.search.substring(1);
  var vars = query.split("&");
  for (var i=0;i<vars.length;i++) {
    var pair = vars[i].split("=");
    if (pair[0] == variable) {
      return pair[1];
    }
  } 
}

</script>
</head><body>
<form method="post" name="theForm" enctype="multipart/form-data">
<table class="forumline" style="width: 100%;" cellpadding="8" cellspacing="0">
<tbody>
<tr>
<td class="row-header" colspan="2">UPDATE MERCHANT DETAILS</td>
</tr>
<tr>
<td colspan="2" align="left">
<a href="merchantlist.php" title="Back " style="font-weight:bold;text-decoration:none;" >&laquo; Back</a>
</td>
</tr>

<?php
    $objTown->getMerchantListWithIDFunction($_GET['merchantid']);
    
    $i=0;
    while($objTown->getRow())
    {
           ?>
		   
<tr>
<td class="row1" style="text-align: right;">Merchant name:</td>
<td class="row1" style="text-align: left;"> <input name="merchantname" id="merchantname" type="text" value="<?PHP echo $objTown->getField('merchantname'); ?>"></td>
</tr>

<tr id="TRusername">
<td class="row1" style="text-align: right;">Merchant Description:</td>
<td class="row1">
<textarea rows="4" cols="50" name="userdescription" id="userdescription"><?PHP echo $objTown->getField('additional_info'); ?></textarea>
</td>
</tr>

<tr id="TRusername">
<td class="row1" style="text-align: right;"></td>
<td class="row1"><input name="submit" value="Update" align="left" type="button" onclick="validateFields()"></td>
</tr>

<?php
    }
    ?>

</tbody></table>

</form>

</body></html>