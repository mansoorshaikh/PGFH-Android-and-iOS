<?PHP
    require_once('../pi_classes/Town.php');
    $objTown=new Town();
    $objTown->updateCategoryFunction($_REQUEST['categoryname'],$_REQUEST['categoryid']);
    
    echo 101;
    ?>