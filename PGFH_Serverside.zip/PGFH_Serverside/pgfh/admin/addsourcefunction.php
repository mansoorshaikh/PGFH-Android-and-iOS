<?PHP
    require_once('../pi_classes/Town.php');
    $objTown=new Town();
    $sourceid=$objTown->addnewsource();
    header('Location: ../parsehtml.php?htmllink='.$_REQUEST['sourcename'].'&sourceid='.$sourceid);
    ?>