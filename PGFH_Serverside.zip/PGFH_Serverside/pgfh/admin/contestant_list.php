<?php
	require_once("../pi_classes/Town.php");
	$objTown=new Town();
    $objTown2=new Town();
    $objTown3=new Town();
    $objTown4=new Town();
    ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html dir="ltr" xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
<script language="JavaScript" src="date.format.js" type="text/javascript"></script>
<script language="JavaScript" src="htmlDatePicker.js" type="text/javascript"></script>
<link href="htmlDatePicker.css" rel="stylesheet" />
<script type="text/javascript" src="js/jquery.js"></script>
<script src="js/common.js" language="javascript"></script>

<?php
    include('include/header.php');
    ?>

<script language="javascript" type="text/javascript">
var rodeo,event,round,noofrounds;
var SITE_URL="http://www.mobiwebcode.com/rodeo";
function onRodeoEventChange(var1){
    document.getElementById("rodeos").value=var1;
    rodeo=document.getElementById("rodeos").value;
    window.location.href = SITE_URL+"/admin/contestant_list.php?rodeoid="+document.getElementById("rodeos").value+"&eventid="+event+"&round"+getParameterByName('round');
}

function editdetails(contestantid){
    window.location.href = SITE_URL+"/admin/contestant_list.php?rodeoid="+document.getElementById("rodeos").value;
}

function editContestant(contestantname,contestantid,eventtype,value){
    window.location.href = "editcontestant_admin.php?eventtype="+eventtype+"&contestantname="+contestantname+"&contestantid="+contestantid+"&round="+getParameterByName('round')+"&value="+value;
}

function deletecontestant(contestantid,contestantname){
    window.location.href = "../deletecontestant_admin.php?eventtype=scored&contestantname=<?php echo $objTown->getField('contestantname') ?>&contestantid=<?php echo $objTown->getField('contestantid') ?>";
}

function onEventValueChange(var1){
    document.getElementById("events").value=var1;
    event=document.getElementById("events").value;
    
    window.location.href = SITE_URL+"/admin/contestant_list.php?eventid="+document.getElementById("events").value+"&rodeoid="+rodeo+"&round=1";
}

function load(){
    rodeo=getParameterByName('rodeoid');
    event=getParameterByName('eventid');
}

function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
    results = regex.exec(location.search);
    return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

function addcontestant(){
    window.location.href = SITE_URL+"/admin/add_contestant.php?rodeoid="+rodeo;
}

function previousround(){
    if(getParameterByName('round')>1){
        window.location.href = "contestant_list.php?eventid="+getParameterByName('eventid')+"&round="+(parseInt(getParameterByName('round'))-1)+"&rodeoid="+getParameterByName('rodeoid');
    }else{
        alert('No Previous Round Available');
    }
}
</script>

<script language="javascript" type="text/javascript">

function gotonextround(){
    $.ajax({
           type: "POST",
           url: "../checknoofrounds.php",
           data: "rodeoid="+rodeo,
           success: function(msg){
           if(msg!="")
           {
           if(parseInt(msg)>parseInt(getParameterByName('round'))){
           window.location.href = "contestant_list.php?eventid="+getParameterByName('eventid')+"&round="+(parseInt(getParameterByName('round'))+1)+"&rodeoid="+getParameterByName('rodeoid');
           }else{
            alert('No Next Round Available');
           }
           }
           }
           });
}

</script>

</head><body onload="load();">
<center><b><font color="#ff0000">
</font></b></center>
<table style="width: 100%;" class="forumline" cellspacing="0">
<tbody><tr>
<td class="row-header" colspan="2"><span>Manage Contestant Details</span></td>
</tr>

<tr>
<td class="message_info" colspan="2" align="center">

</td>
</tr>


<tr><td>&nbsp;
<center><b><font color="#ff0000">
</font></b></center>

</td></tr>
<tr>
<td colspan="2" align="left"><font size="2"><b> <a href="#" title="Add Contestant" onclick="addcontestant()" style="text-decoration:none;font-weight:bold;">Add New Contestant &raquo;  </a></td>
</tr>
<tr>
<td colspan="2" align="left">
<a href="#" title="Previous Round" onclick="previousround()" style="text-decoration:none;font-weight:bold;"> &#171; Previous Round </a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="#" title="Next Round" onclick="gotonextround()" style="text-decoration:none;font-weight:bold;">Next Round &raquo;  </a></b></b></font>
</td>
</tr>
<tr><td>&nbsp;</td></tr>
<tr>
<td class="row1" colspan="2">
<center>
<table style="width: 1200px;">
<tbody>

<tr>
<th width="200">
<select id="rodeos" onchange="onRodeoEventChange(this.value)">
<?php
    $objTown->getRodeoList();
    while($objTown->getRow())
    {
        if($objTown->getField('rodeoid')==$_REQUEST['rodeoid']){?>
<option value=<?php echo $objTown->getField('rodeoid'); ?> selected="selected"><?php echo $objTown->getField('rodeoname');  ?></option>
<?php        }else{
    ?>
<option value=<?php echo $objTown->getField('rodeoid'); ?>><?php echo $objTown->getField('rodeoname');  ?></option>
<?php }}?>
</select>
</th>
<th width="200"><select id="events" name="events" onchange="onEventValueChange(this.value)">
<?php
    $objTown->getEventsList();
    while($objTown->getRow())
    {
        if($objTown->getField('eventid')==$_REQUEST['eventid']){?>
<option value=<?php echo $objTown->getField('eventid'); ?> selected="selected"><?php echo $objTown->getField('eventname');  ?></option>
<?php        }else{
    ?>
<option value=<?php echo $objTown->getField('eventid'); ?>><?php echo $objTown->getField('eventname');  ?></option>
<?php }}
    $objTown2->getEventsListwithID($_REQUEST['eventid']);
    $objTown2->getRow();?>
</select></th>
</tr>

<tr>
<th width="50">Sr.No</th>
<th width="200">contestant Name</th>
<?PHP if($objTown2->getField('eventtype')=="scored"){ ?>
<th width="100" id="THscore">Score</th>
<?PHP } else{ ?>
<th width="100" id="THtime">Time</th>
<?PHP } ?>
<th width="100">Avg</th>
<?PHP if($objTown2->getField('eventtype')=="timed"){ ?>
<th width="100">Total Time</th>
<?PHP } ?>
<th width="100">First In Round</th>
<th width="100">Last In Round</th>
<th width="100">First In Avg</th>
<th width="100">Last In Avg</th>
<th width="100">Actions</th>
<?php
    $objTown->getContestantsList();
    $i=0;
    while($objTown->getRow())
    {
            $objTown3->getcontestantsScore($objTown->getField('contestantid'),$_REQUEST['round']);
            $objTown3->getRow();
        ?>
<tr>
<td class="row1" style="font-size: 9pt;text-align:center;">
<?php echo ++$i; ?>
</td>

<td class="row1" style="font-size: 9pt;">
<?PHP echo $temp= $objTown->getField('contestantname'); ?>
</td>
<?PHP if($objTown2->getField('eventtype')=="scored"){
    $objTown4->getRow();?>
<td class="row1" style="font-size: 9pt;" id="TDscore">
<?PHP echo $objTown3->getField('score'); ?>
</td>

<?PHP } else{ ?>
<td class="row1" style="font-size: 9pt;" id="TDtime">
<?PHP echo $objTown3->getField('time'); ?>
</td>
<?PHP } ?>
<td class="row1" style="font-size: 9pt;">
<?php echo $objTown4->getContestantsAvg($objTown->getField('contestantid'),$_REQUEST['round'],$objTown2->getField('eventtype'));
    ?>
</td>
<?PHP if($objTown2->getField('eventtype')=="timed"){ ?>
<td class="row1" style="font-size: 9pt;">
0
</td>
<?PHP } ?>
<td class="row1" style="font-size: 9pt;">
0
</td>

<td class="row1" style="font-size: 9pt;">
0
</td>
<td class="row1" style="font-size: 9pt;">
0
</td>
<td class="row1" style="font-size: 9pt;">
0
</td>

<td class="row1" style="font-size: 9pt;">
<a href="#" onclick="editContestant('<?php echo $objTown->getField('contestantname') ?>','<?php echo $objTown->getField('contestantid') ?>','<?php echo $objTown2->getField('eventtype') ?>','<?php echo $objTown3->getField('score') ?>')">Edit</a>
<a href="#" onclick="deletecontestant('<?php $objTown->getField('contestantname') ?>','<?php $objTown3->getField('contestantid') ?>','<?php echo $objTown2->getField('eventtype') ?>')">Delete</a>
</td>

</tr>
<?php
    }
    ?>
</tbody>

</table>
</center>
</td>
</tr>

<script type="text/javascript" src="http://mediaplayer.yahoo.com/js"></script>
</tbody></table></body></html>
