


<div id="contraner">
<div id="wrapper">
	<div id="header">
    	<div class="navbar">
        	<ul>
            	<li><a href="../index.html">HOME</a></li>
                <li><a href="../about-us.html">About Us</a></li>
                <li><a href="../features.html">Features</a></li>
                <li><a href="../my-rodeo.html">My Rodeo app for Rodeo Producers</a></li>
            </ul>
        </div>
        <div id="heading"> <font color="#ae1113">Administration Panel</font></div>
    </div>
