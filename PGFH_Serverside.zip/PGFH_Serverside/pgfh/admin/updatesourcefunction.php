<?PHP
    require_once('../pi_classes/Town.php');
    $objTown=new Town();
    $objTown->updatesource();
    header('Location: sourceslist.php');
    ?>