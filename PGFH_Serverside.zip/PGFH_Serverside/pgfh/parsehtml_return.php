<?php
    require_once("simple_html_dom.php");
    require_once('pi_classes/Town.php');
    
    $count=0;
    parseHTML($_REQUEST['htmllink']);
    
    
    function parseHTML($link_){
        $count=0;
        $dom = new DOMDocument;
        $dom->loadHTML(file_get_contents('http://'.$link_));
        foreach($dom->getElementsByTagName('a') as $link)
        {
            $href = $link->getAttribute('href');
            $anchor = $link->nodeValue;
            $linksArray[$count]=$href;
            $count++;
        }
        $linksArray=array_unique($linksArray);
        $linksArray[0]='http://'.$link_;
        for($i=0;$i<count($linksArray);$i++){
            parseInnerPages($linksArray[$i]);
            //echo $linksArray[$i];
            if($i==15)
                break;
        }
    }
    
    function parseInnerPages($link_){
        $objTown=new Town();
        $dom = new DOMDocument;
        $dom->loadHTML(file_get_contents($link_));
        foreach($dom->getElementsByTagName('iframe') as $link)
        {
            $href = $link->getAttribute('src');
            if ((strpos($href,'youtube') !== false) OR (strpos($href,'vimeo') !== false)){
                echo $href."+#+#";
              //  $objTown->addmusiclink($_REQUEST['sourceid'],str_replace("//","",$href),'');
            }
        }
        if($objs = $dom->getElementsByTagName('object')){
            foreach($objs as $o){
                foreach($o->childNodes as $p){
                    if(preg_match('/^param$/i', $p->nodeName)){
                        $split=explode("soundFile=",$p->getAttribute('value'));
                        echo $split[1]."+#+#";
                       // if (strpos($href,'.mp3') !== false)
                     //       $objTown->addmusiclink($_REQUEST['sourceid'],$href,'');
                    }
                }
            }
        }
        foreach($dom->getElementsByTagName('a') as $link){
            $href = $link->getAttribute('href');
            $anchor = $link->nodeValue;
            if (strpos($href,'.mp3') !== false){
                echo $href."+#".$anchor."+#";
             //   $objTown->addmusiclink($_REQUEST['sourceid'],$href,$anchor);
            }
            else if(preg_match('/http:\/\/www\.youtube\.com\/watch\?v=[^&]+/', $href, $result)) {
                echo $href."+#".$anchor."+#";
              //  $objTown->addmusiclink($_REQUEST['sourceid'],$href,$anchor);
            }
        }
    }
    
    ?>