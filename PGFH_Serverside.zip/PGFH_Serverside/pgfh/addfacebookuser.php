<?php
	require_once("pi_classes/Town.php");
    
	$objTown=new Town();
	
    $objTown->getUserListFunction();
	$isMerchant=0;
    while($objTown->getRow())
    {
        $firstUserID=$objTown->getField('userid');
		$facebookUserID=$objTown->getField('facebookuserid');

		if($facebookUserID==$_REQUEST['facebookuserid']){
			echo $objTown->getField('isMerchant');
			$isMerchant=1;
			break;
		}
    }
	if($isMerchant==0){
		$objTown->addFacebookUserInfo();
		echo $firstUserID+1;
	}
?>