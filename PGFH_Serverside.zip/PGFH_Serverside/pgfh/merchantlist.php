<?php

	require_once("pi_classes/Town.php");
    
	$objTown=new Town();
	
	$objTown->getMerchantListFunction();
	
		$xml='<?xml version="1.0" standalone="yes"?>';
		$xml.='<merchantlist>';	
		 while($objTown->getRow()){
			$xml.='<merchant>';
			$xml.="<merchantid>". $objTown->getField('merchant_user_id') ."</merchantid>";
			$xml.="<merchantname>". $objTown->getField('merchantname') ."</merchantname>";
			$xml.="<merchantdescription>". $objTown->getField('additional_info')."</merchantdescription>";
			$xml.='</merchant>';
		}
		$xml.='</merchantlist>';
		echo $xml;
?>