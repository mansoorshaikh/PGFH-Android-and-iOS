<?php
	require_once("pi_classes/Town.php");
    
	$objTown=new Town();
	
    $objTown->getcategoryListFunction();
 
    while($objTown->getRow())
    {
        echo $objTown->getField('categoryname')."a1b2c3";
    }
	
	echo $firstUserID;
?>