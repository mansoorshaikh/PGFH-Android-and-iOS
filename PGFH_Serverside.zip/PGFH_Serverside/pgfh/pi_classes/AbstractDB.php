<?php
define('SITE_PATH','http://www.syneotek.com/carparts/');
ini_set('display_errors', 0);
	class AbstractDB
	{
    /*    const HOST='localhost';        //host name
        const USER='root';             //user name DB
        const PASS='';
        const DB='pgfh';
        const SUFFIX='';
        const SITE_PATH='http://www.syneotek.com/TripMe/';*/
		
	    const HOST='localhost';        //host name
        const USER='mobiwebc_pgfh';             //user name DB
        const PASS='mobiwebc_pgfh';
        const DB='mobiwebc_pgfhdb';
        const SUFFIX='';
        const SITE_PATH='http://www.syneotek.com/TripMe/';
        
	public function AbstractDB()
	{
		$this->mysql=mysqli_connect(self::HOST,self::USER,self::PASS,self::DB);
    }
	
	protected function query($sql)
	{
		return mysqli_query($this->mysql,$sql);
	}
	
	public function getRow()
	{
		if($this->row=mysqli_fetch_assoc($this->result))
		{
			return true;	
		}
			return false;
	}
	
	public function getObj($className,$fileName)
	{
		require_once($fileName.'.php');
		$this->obj[$className]=new $className();
	}
	
	public function getField($filedName)
	{
		return $this->row[$filedName];
	}
	
	public function numofrows()
	{
		return mysqli_num_rows($this->result);
	}
	
	public function getInsertedId()
	{
	return mysql_insert_id($this->mysql);
	}
	
	
	public function escape_string($str)
	{
		return mysqli_real_escape_string($this->mysql,$str);	
	}
	
	public function multy_result()
	{
		$arr=NULL;
		while($this->row=mysqli_fetch_assoc($this->result))
		{
			$arr[]=$this->row;
		}
			return $arr;
			
	}
}

?>
