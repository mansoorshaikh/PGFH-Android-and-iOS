<?php
require_once('AbstractDB.php');

class Admin extends AbstractDB
{
	 function __construct()
	{
		parent::__construct();
	}
	
	 function getAdminDetails($adminId)
	{
		$str="SELECT * FROM admin_details WHERE `adminid`=".$adminId;
		$this->result=$this->query($str);
	}
	
	 function updateAdminDetails($adminId,$emailId)
	{
		$str="UPDATE ".parent::SUFFIX."admin_details SET email_id='".$this->escape_string($emailId)."',`updated_on`='".date('Y-m-d H:i:s')."' WHERE `id`='".$this->escape_string($adminId)."'";	
		return $this->query($str);
	}
	
	 function chkLoginDetails($userName,$password)
	{
		$str="SELECT * FROM `admin_details` WHERE `username`='".$userName."' AND `password`='".$password."'";
		
		$this->result=$this->query($str);
	}
	
	 function updateLastLogin($adminId)
	{
	$str="UPDATE ".parent::SUFFIX."admin_details SET `login_on`='".date('Y-m-d H:i:s')."' WHERE `id`='".$this->escape_string($adminId)."'";	
	return $this->query($str);
	}
	
	 function changePassword($adminId,$newPass)
	{
		$str="UPDATE admin_details SET `password`='".$newPass."' WHERE `adminid`=".$adminId;	
		return $this->query($str);		
	}
	
       
	//   setting in admin panel
	function getAllRMealsServed()
	{
		 
	   $str="select * from ".parent::SUFFIX."meals_served";
		 $this->result=$this->query($str);

		}
	function updateTownState($st,$id)
	{
	     $str="UPDATE ".parent::SUFFIX."user SET `status` = '".$st."' WHERE `uid` ='".$id."'";
		 $this->result=$this->query($str);

	}
	function updateTypeState($st,$id)
	{
	     $str="UPDATE ".parent::SUFFIX."channels SET `status` = '".$st."' WHERE `cid` ='".$id."'";
		 $this->result=$this->query($str);

	}
	function updateRestaurentState($st,$id)
	{
		  $str="UPDATE ".parent::SUFFIX."registation SET `featured` = '".$st."' WHERE `id` ='".$id."'";
		 $this->result=$this->query($str);
	
	}
	
	function  updateRestaurentReview($st,$id)
	{
		 	  $str="UPDATE ".parent::SUFFIX."review SET `status` = '".$st."' WHERE `id` ='".$id."'";
		 $this->result=$this->query($str);

  }
	function getMyReview($id)
	{
	      $str="select * from ".parent::SUFFIX."review where rid='".$id."'";
		 $this->result=$this->query($str);

	}
		
    
			 	
	
}

?>