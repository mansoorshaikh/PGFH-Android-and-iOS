<?php
	require_once('AbstractDB.php');
	
	class Town extends AbstractDB
	{
		function __construct()
		{
			parent::__construct();
		}
        
        function chkLoginDetails($username,$password){
            $str="select * from admin where username='".$username."' and password='".$password."'";
            $this->result=$this->query($str);
        }
		
		
		function addfoodpost($fooddetails,$picturepath){
			$str="insert into foodpost(foodpostid,outlet,location,price,description,tasterating,tasteratingdesc,pricerating,priceratingdesc
				,hyginnserating,hygennseratingdesc,servicerating,serviceratingdesc,picture) values(NULL,'".$fooddetails[0]."','".$fooddetails[1]."','".  				$fooddetails[2]."','".$fooddetails[3]."','".$fooddetails[4]."','".$fooddetails[5]."','".$fooddetails[6]."','".$fooddetails[7]."',
				'".$fooddetails[8]."','".$fooddetails[9]."','".$fooddetails[10]."','".$fooddetails[11]."','".$picturepath."')";
				echo $str;
			$this->result=$this->query($str);
		}
		
		function addadvtpost($fooddetails,$picturepath){
		 $str="insert into advtpost(advtpostid,outlet,location,latitude,longitude,contact,description,image) values(NULL,'".$fooddetails[0]."','".	
		 $fooddetails[1]."','".$fooddetails[2]."','".$fooddetails[3]."','".$fooddetails[4]."','".$fooddetails[5]."','".$picturepath."')";
		 echo $str;
		$this->result=$this->query($str);
		}
		
		 function getUserListFunction(){
            $str="select * from user_information";
            $this->result=$this->query($str);
        }
		
		function getFoodPostListFunction(){
            $str="select * from foodpost";
            $this->result=$this->query($str);
        }
		
		function getAdvtPostListFunction(){
            $str="select * from advtpost";
            $this->result=$this->query($str);
        }
		
		function getAdvtPostFunction($advtpostid){
		  $str="select * from advtpost where advtpostid=".$advtpostid;
		  echo $str;
          $this->result=$this->query($str);
		}
		
		function addFacebookUserInfo(){
            $str="insert into user_information(userid,username,facebookuserid,facebookname,email,isMerchant) values(NULL,'".str_replace("_"
			," ",$_REQUEST['username'])."','".$_REQUEST['facebookuserid']."','".str_replace("_"
			," ",$_REQUEST['facebookname'])."','".$_REQUEST['email']."','normal')";
			$this->result=$this->query($str);
        }
		
		 function getMerchantListFunction(){
            $str="select * from merchant_info";
            $this->result=$this->query($str);
        }
		
		 function getcategoryListFunction(){
            $str="select * from category";
            $this->result=$this->query($str);
        }
		
		function getcategoryListWithIDFunction($categoryid){
            $str="select * from category where categoryid=".$categoryid;
            $this->result=$this->query($str);
        }
		
		 function getUserListWithIDFunction($userid){
            $str="select * from user_information where userid=".$userid;
            $this->result=$this->query($str);
        }
		
		 function getMerchantListWithIDFunction($merchantid){
            $str="select * from merchant_info where merchant_user_id=".$merchantid;
            $this->result=$this->query($str);
        }
		
		function updateAdvtPostFunction(){
			$str="update advtpost set poststatus='".$_REQUEST['status']."' where advtpostid=".$_REQUEST['advtpostid'];
            $this->result=$this->query($str);
		}

		
		function updateUserInfoFunction($userdescription,$userid){
			$str="update user_information set additional_info='".$userdescription."' where userid=".$userid;
            $this->result=$this->query($str);
		}
		
		function updateMerchantFunction($merchantname,$merchantid,$merchantdesc){
			$str="update merchant_info set merchantname='".$merchantname."', additional_info='".$merchantdesc."'  where merchant_user_id=".$merchantid;
            $this->result=$this->query($str);
		}
		
		function addmerchant_function($merchantname,$merchantdesc){
			$str="insert into merchant_info(merchant_user_id,merchantname,additional_info) values (NULL,'".$merchantname."','".$merchantdesc."')";
            $this->result=$this->query($str);
		}
		
		function addcategory_function($categoryname){
			$str="insert into category(categoryid,categoryname) values (NULL,'".$categoryname."')";
            $this->result=$this->query($str);
		}
		
		function updateCategoryFunction($categoryname,$categoryid){
			$str="update category set categoryname='".$categoryname."' where categoryid=".$categoryid;
            $this->result=$this->query($str);
		}
		
        
    }
    ?>
