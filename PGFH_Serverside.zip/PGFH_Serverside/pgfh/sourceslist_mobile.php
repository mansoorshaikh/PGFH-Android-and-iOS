<?PHP
    require_once('pi_classes/Town.php');
    $objTown=new Town();
    $objTown->getSourcesList();
    $i=0;
    while($objTown->getRow()){
        $sourcesArray[$i]=$objTown->getField('sourcename');
        $i++;
    }
    sort($sourcesArray);
    for($k=0;$k<count($sourcesArray);$k++){
        $objTown->getSourceID($sourcesArray[$k]);
        $objTown->getRow();
        echo $objTown->getField('sourceid')."+#".$sourcesArray[$k]."+#";
    }
?>