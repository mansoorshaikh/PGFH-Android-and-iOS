<?PHP
    require_once('pi_classes/Town.php');
    $objTown=new Town();
    $objTown->getMusicListfunction();
    while($objTown->getRow()){
        echo $objTown->getField('linkname')."+#";
    }
?>